const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_parent_1";
const BOB_UID = "bob_parent_2";
const ADMIN_UID = "admin_user_1";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(offsetMs = 2000) {
  return new Date(Date.now() - offsetMs);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any TOTOCARE collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("children").get());
  await assertFails(unauthDb.collection("consultations").where("parentUid", "==", ALICE_UID).get());
  await assertFails(unauthDb.collection("pharmacyOrders").where("parentUid", "==", ALICE_UID).get());
  await assertFails(unauthDb.collection("healthBulletins").where("published", "==", true).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      fullName: "Hacker",
      caregiverRole: "parent",
      language: "en",
      countryCode: "TZ",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
});

test("User profile and child medical profile: owner CRUD succeeds, cross-user & ghost fields fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const now = pastDate(5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      fullName: "Amina Juma",
      email: "alice@example.com",
      phone: "+255712345678",
      caregiverRole: "parent",
      language: "sw",
      countryCode: "TZ",
      workspaceRole: "parent",
      emergencyContactName: "Juma Hassan",
      emergencyContactPhone: "+255713000111",
      twoFactorEnabled: true,
      notificationsEnabled: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Ghost field rejection
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: pastDate(),
    })
  );

  // Child create (NO id field inside doc)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("children").doc("child_1").set({
      userId: ALICE_UID,
      fullName: "Neema Juma",
      dobText: "2024-03-10",
      ageMonths: 20,
      ageGroup: "TODDLER",
      gender: "Female",
      birthWeightKg: 3.2,
      bloodGroup: "O+",
      location: "Kinondoni, Dar es Salaam",
      allergies: "None",
      previousIllnesses: "Mild URI",
      existingConditions: "None",
      medications: "None",
      emergencyContactName: "Amina Juma",
      emergencyContactPhone: "+255712345678",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Reject @DocumentId "id" key injection
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("children").doc("child_2").set({
      id: "child_2",
      userId: ALICE_UID,
      fullName: "Bad Child",
      dobText: "2024-01-01",
      ageMonths: 10,
      ageGroup: "INFANT",
      gender: "Male",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Cross-user isolation
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("children").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("children").doc("child_1").get());
});

test("Vaccinations, growth logs, assessments, and notifications work for owner and reject future timestamps", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = pastDate(5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("vaccinations").doc("vac_1").set({
      userId: ALICE_UID,
      childId: "child_1",
      childName: "Neema Juma",
      vaccineName: "Measles-Rubella (MR 1)",
      ageScheduleLabel: "9 Months",
      doseLabel: "Dose 1",
      status: "upcoming",
      scheduledDateText: "2026-12-01",
      clinicName: "Muhimbili RCH Clinic",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("vaccinations").doc("vac_1").update({
      status: "completed",
      administeredDateText: "2026-11-24",
      updatedAt: pastDate(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("growthLogs").doc("grow_1").set({
      userId: ALICE_UID,
      childId: "child_1",
      childName: "Neema Juma",
      weightKg: 10.4,
      heightCm: 81.5,
      headCircumferenceCm: 46.5,
      recordedDateText: "2026-11-24",
      milestoneNote: "Walking steadily and speaking 10+ words",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("assessments").doc("assm_1").set({
      userId: ALICE_UID,
      childId: "child_1",
      childName: "Neema Juma",
      kind: "symptom",
      ageGroup: "TODDLER",
      symptomsSummary: "Fever 38.6C for 1 day, cough",
      riskLevel: "ORANGE",
      aiExplanation: "Urgent pediatric assessment recommended to evaluate fever and cough.",
      nextSteps: "Monitor breathing, hydrate, consult a pediatrician today.",
      emergencyTriggered: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Reject future timestamp
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("notifications").doc("notif_1").set({
      userId: ALICE_UID,
      childId: "child_1",
      title: "Upcoming MR Vaccine",
      body: "Due next week",
      category: "vaccine",
      readStatus: false,
      createdAt: new Date(Date.now() + 60000),
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Consultations and pharmacy orders: filtered queries succeed, unfiltered fail, completed state locks", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = pastDate(5000);

  await assertSucceeds(
    aliceDb.collection("consultations").doc("cons_1").set({
      parentUid: ALICE_UID,
      parentName: "Amina Juma",
      childId: "child_1",
      childName: "Neema Juma",
      doctorId: "doc_1",
      doctorName: "Dr. Neema Mushi",
      specialty: "General Pediatrics",
      consultationMode: "video",
      scheduledSlot: "Today, 14:30 EAT",
      symptomsSummary: "Persistent fever and reduced appetite",
      attachmentSummary: "Photo attached",
      status: "requested",
      doctorNotes: "",
      prescriptionText: "",
      referralSpecialty: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Filtered query succeeds; unfiltered query fails
  await assertSucceeds(aliceDb.collection("consultations").where("parentUid", "==", ALICE_UID).get());
  await assertFails(aliceDb.collection("consultations").get());
  await assertFails(bobDb.collection("consultations").where("parentUid", "==", ALICE_UID).get());

  // Nested consultation message with denormalized parentUid
  await assertSucceeds(
    aliceDb.collection("consultations").doc("cons_1").collection("messages").doc("msg_1").set({
      parentUid: ALICE_UID,
      senderUid: ALICE_UID,
      senderName: "Amina Juma",
      senderRole: "parent",
      body: "Doctor, her temperature is 38.6C.",
      createdAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("consultations").doc("cons_1").collection("messages").where("parentUid", "==", ALICE_UID).get()
  );

  // Complete consultation -> terminal state locking prevents further non-admin updates
  await assertSucceeds(
    aliceDb.collection("consultations").doc("cons_1").update({
      status: "completed",
      doctorNotes: "Hydration + paracetamol weight-based guidance",
      updatedAt: pastDate(),
    })
  );
  await assertFails(
    aliceDb.collection("consultations").doc("cons_1").update({
      doctorNotes: "Tampered note after completion",
      updatedAt: pastDate(),
    })
  );

  // Pharmacy order
  await assertSucceeds(
    aliceDb.collection("pharmacyOrders").doc("ord_1").set({
      parentUid: ALICE_UID,
      parentName: "Amina Juma",
      childName: "Neema Juma",
      pharmacyName: "Kariakoo Care Pharmacy",
      medicineName: "Oral Rehydration Salts (ORS) Pack",
      quantity: 2,
      totalTzs: 6000,
      requiresPrescription: false,
      prescriptionNote: "",
      deliveryMode: "delivery",
      deliveryAddress: "Kinondoni, Dar es Salaam",
      status: "pending_verification",
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("pharmacyOrders").where("parentUid", "==", ALICE_UID).get());
  await assertFails(aliceDb.collection("pharmacyOrders").get());
});

test("Provider applications prevent self-verification and spoofed admin email", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const spoofAdminDb = testEnv.authenticatedContext("spoof_1", { email: "georgemihotz@gmail.com", email_verified: false }).firestore();
  const realAdminDb = testEnv.authenticatedContext(ADMIN_UID, { email: "georgemihotz@gmail.com", email_verified: true }).firestore();
  const now = pastDate(5000);

  // Cannot create directly as verified
  await assertFails(
    aliceDb.collection("providerApplications").doc(ALICE_UID).set({
      userId: ALICE_UID,
      providerType: "doctor",
      applicantName: "Dr. Alice",
      facilityName: "Clinic",
      licenseNumber: "MCT-1234",
      specialty: "Pediatrics",
      region: "Dar es Salaam",
      verificationStatus: "verified",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Pending creation succeeds
  await assertSucceeds(
    aliceDb.collection("providerApplications").doc(ALICE_UID).set({
      userId: ALICE_UID,
      providerType: "doctor",
      applicantName: "Dr. Alice",
      facilityName: "Clinic",
      licenseNumber: "MCT-1234",
      specialty: "Pediatrics",
      region: "Dar es Salaam",
      verificationStatus: "pending",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Owner cannot self-verify
  await assertFails(
    aliceDb.collection("providerApplications").doc(ALICE_UID).update({
      verificationStatus: "verified",
      updatedAt: pastDate(),
    })
  );

  // Spoofed unverified admin email rejected
  await assertFails(
    spoofAdminDb.collection("providerApplications").doc(ALICE_UID).update({
      verificationStatus: "verified",
      updatedAt: pastDate(),
    })
  );

  // Verified admin succeeds
  await assertSucceeds(
    realAdminDb.collection("providerApplications").doc(ALICE_UID).update({
      verificationStatus: "verified",
      updatedAt: pastDate(),
    })
  );

  // Official health bulletin: admin publishes, signed-in user reads published == true
  await assertSucceeds(
    realAdminDb.collection("healthBulletins").doc("bul_1").set({
      title: "Tanzania EPI Measles-Rubella Campaign",
      source: "Tanzania Ministry of Health",
      publishedDate: "2026-11-15",
      category: "Vaccination",
      summary: "All children aged 9 to 59 months are eligible for MR catch-up immunization.",
      language: "en",
      published: true,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("healthBulletins").where("published", "==", true).get());
  await assertFails(aliceDb.collection("healthBulletins").get());
});
