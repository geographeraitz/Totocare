package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.GlobalCountryCatalog
import com.example.data.ChildProfile
import com.example.data.ConsultationRecord
import com.example.data.HealthAssessment
import com.example.data.PharmacyOrder
import com.example.data.ProviderApplication
import com.example.data.UserProfile
import com.example.data.WorkspaceRole
import com.example.ui.components.SectionHeader
import com.example.ui.theme.HealthcareTeal
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RiskGreen
import com.example.ui.theme.RiskOrange
import com.example.ui.theme.RiskRed
import com.example.ui.theme.SoftLightBlue
import com.example.ui.theme.SoftTealTint

@Composable
fun PortalsScreen(
    workspaceRole: WorkspaceRole,
    onSwitchWorkspaceRole: (WorkspaceRole) -> Unit,
    userProfile: UserProfile?,
    userEmail: String,
    isAdminUser: Boolean,
    language: AppLanguage,
    children: List<ChildProfile>,
    assessments: List<HealthAssessment>,
    consultations: List<ConsultationRecord>,
    pharmacyOrders: List<PharmacyOrder>,
    providerApplication: ProviderApplication?,
    onSaveAccountSettings: (String, String, String, String, String, String, Boolean, Boolean) -> Unit,
    onSignOut: () -> Unit,
    onSubmitProviderCredentials: (String, String, String, String, String, String) -> Unit,
    onUpdateConsultationDoctor: (String, String, String, String, String) -> Unit,
    onAdvancePharmacyOrder: (String, String) -> Unit,
    onPublishBulletin: (String, String, String, String, String, String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            WorkspaceRole.entries.forEach { role ->
                FilterChip(
                    selected = workspaceRole == role,
                    onClick = { onSwitchWorkspaceRole(role) },
                    label = {
                        Text(if (language == AppLanguage.KISWAHILI) role.labelSw else role.labelEn)
                    }
                )
            }
        }

        when (workspaceRole) {
            WorkspaceRole.PARENT -> ParentAccountPortal(
                userProfile = userProfile,
                userEmail = userEmail,
                onSave = onSaveAccountSettings,
                onSignOut = onSignOut
            )
            WorkspaceRole.DOCTOR -> DoctorPortal(
                providerApplication = providerApplication,
                consultations = consultations,
                onSubmitCredentials = onSubmitProviderCredentials,
                onUpdateConsultation = onUpdateConsultationDoctor
            )
            WorkspaceRole.PHARMACY -> PharmacyPortal(
                providerApplication = providerApplication,
                orders = pharmacyOrders,
                onSubmitCredentials = onSubmitProviderCredentials,
                onAdvanceOrder = onAdvancePharmacyOrder
            )
            WorkspaceRole.ADMIN -> AdminPortal(
                isAdminUser = isAdminUser,
                children = children,
                assessments = assessments,
                consultations = consultations,
                pharmacyOrders = pharmacyOrders,
                onPublishBulletin = onPublishBulletin
            )
        }
    }
}

@Composable
private fun ParentAccountPortal(
    userProfile: UserProfile?,
    userEmail: String,
    onSave: (String, String, String, String, String, String, Boolean, Boolean) -> Unit,
    onSignOut: () -> Unit
) {
    var fullName by remember(userProfile?.userId) { mutableStateOf(userProfile?.fullName ?: "") }
    var phone by remember(userProfile?.userId) { mutableStateOf(userProfile?.phone ?: "") }
    var caregiverRole by remember(userProfile?.userId) { mutableStateOf(userProfile?.caregiverRole ?: "parent") }
    var countryCode by remember(userProfile?.userId) { mutableStateOf(userProfile?.countryCode ?: "TZ") }
    var emergencyName by remember(userProfile?.userId) { mutableStateOf(userProfile?.emergencyContactName ?: "") }
    var emergencyPhone by remember(userProfile?.userId) { mutableStateOf(userProfile?.emergencyContactPhone ?: "") }
    var twoFactor by remember(userProfile?.userId) { mutableStateOf(userProfile?.twoFactorEnabled ?: true) }
    var notifications by remember(userProfile?.userId) { mutableStateOf(userProfile?.notificationsEnabled ?: true) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            SectionHeader("Parent Account, Security & Country", "Signed in as $userEmail • International Multi-Country Architecture")
        }

        item {
            OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number (e.g. +255...)") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            Text("Caregiver Role:", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("parent", "guardian", "caregiver").forEach { r ->
                    FilterChip(selected = caregiverRole == r, onClick = { caregiverRole = r }, label = { Text(r.replaceFirstChar { it.uppercase() }) })
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Country & National Health Rules:", style = MaterialTheme.typography.labelLarge)
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GlobalCountryCatalog.countries.forEach { c ->
                    FilterChip(selected = countryCode == c.code, onClick = { countryCode = c.code }, label = { Text("${c.flagEmoji} ${c.name}") })
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = emergencyName, onValueChange = { emergencyName = it }, label = { Text("Primary Emergency Contact Name") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = emergencyPhone, onValueChange = { emergencyPhone = it }, label = { Text("Emergency Contact Phone") }, modifier = Modifier.fillMaxWidth())
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Two-Factor & Biometric Guard", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text("Google identity protection & parental consent verification", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = twoFactor, onCheckedChange = { twoFactor = it })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Smart Vaccine & Clinic Reminders", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text("Alerts for EPI schedules, follow-ups & doctor replies", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = notifications, onCheckedChange = { notifications = it })
                    }
                }
            }
        }

        item {
            Button(
                onClick = { onSave(fullName, phone, caregiverRole, countryCode, emergencyName, emergencyPhone, twoFactor, notifications) },
                modifier = Modifier.fillMaxWidth().testTag("save_account_button")
            ) {
                Text("Save Account & Country Settings")
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(
                onClick = onSignOut,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = RiskRed),
                modifier = Modifier.fillMaxWidth().testTag("sign_out_button")
            ) {
                Text("Sign Out Safely")
            }
        }
    }
}

@Composable
private fun DoctorPortal(
    providerApplication: ProviderApplication?,
    consultations: List<ConsultationRecord>,
    onSubmitCredentials: (String, String, String, String, String, String) -> Unit,
    onUpdateConsultation: (String, String, String, String, String) -> Unit
) {
    var applicantName by remember(providerApplication?.userId) { mutableStateOf(providerApplication?.applicantName ?: "") }
    var facilityName by remember(providerApplication?.userId) { mutableStateOf(providerApplication?.facilityName ?: "") }
    var licenseNo by remember(providerApplication?.userId) { mutableStateOf(providerApplication?.licenseNumber ?: "") }
    var specialty by remember(providerApplication?.userId) { mutableStateOf(providerApplication?.specialty ?: "Pediatrics") }
    var region by remember(providerApplication?.userId) { mutableStateOf(providerApplication?.region ?: "Dar es Salaam") }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            SectionHeader("Doctor & Healthcare Provider Dashboard", "Credential verification, parent consultations, prescriptions & specialist referrals")
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SoftLightBlue), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val status = providerApplication?.verificationStatus?.uppercase() ?: "NOT SUBMITTED"
                    Text("Credential Verification Status: $status", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = PrimaryBlue)
                    OutlinedTextField(value = applicantName, onValueChange = { applicantName = it }, label = { Text("Clinician Full Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = facilityName, onValueChange = { facilityName = it }, label = { Text("Hospital / Clinic") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = licenseNo, onValueChange = { licenseNo = it }, label = { Text("MCT / License #") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = specialty, onValueChange = { specialty = it }, label = { Text("Specialty") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = region, onValueChange = { region = it }, label = { Text("Region") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = { onSubmitCredentials("doctor", applicantName, facilityName, licenseNo, specialty, region) },
                        enabled = applicantName.isNotBlank() && facilityName.isNotBlank() && licenseNo.isNotBlank() && specialty.isNotBlank() && region.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (providerApplication == null) "Submit Credentials for Verification" else "Update Credential Profile")
                    }
                }
            }
        }

        item {
            SectionHeader("Consultation Queue & Clinical Notes")
        }

        items(consultations, key = { it.id }) { consult ->
            var notes by remember(consult.id) { mutableStateOf(consult.doctorNotes) }
            var rx by remember(consult.id) { mutableStateOf(consult.prescriptionText) }
            var referral by remember(consult.id) { mutableStateOf(consult.referralSpecialty) }

            Card(shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${consult.childName} • Mode: ${consult.consultationMode.uppercase()} • Status: ${consult.status}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("Reported: ${consult.symptomsSummary}", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Doctor Consultation Notes") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = rx, onValueChange = { rx = it }, label = { Text("Authorized Prescription") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = referral, onValueChange = { referral = it }, label = { Text("Specialist Referral (e.g. Pediatric Cardiologist)") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onUpdateConsultation(consult.id, "in_progress", notes, rx, referral) },
                            enabled = consult.status != "completed",
                            modifier = Modifier.weight(1f)
                        ) { Text("Save Draft") }
                        Button(
                            onClick = { onUpdateConsultation(consult.id, "completed", notes, rx, referral) },
                            enabled = consult.status != "completed",
                            modifier = Modifier.weight(1f)
                        ) { Text(if (consult.status == "completed") "Completed" else "Complete & Issue Rx") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PharmacyPortal(
    providerApplication: ProviderApplication?,
    orders: List<PharmacyOrder>,
    onSubmitCredentials: (String, String, String, String, String, String) -> Unit,
    onAdvanceOrder: (String, String) -> Unit
) {
    var pharmacyName by remember(providerApplication?.userId) { mutableStateOf(providerApplication?.facilityName ?: "") }
    var pharmacistName by remember(providerApplication?.userId) { mutableStateOf(providerApplication?.applicantName ?: "") }
    var tmdaLicense by remember(providerApplication?.userId) { mutableStateOf(providerApplication?.licenseNumber ?: "") }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            SectionHeader("Licensed Pharmacy Partner Dashboard", "TMDA compliance, prescription verification & order dispatch")
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SoftTealTint), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Business Onboarding (${providerApplication?.verificationStatus?.uppercase() ?: "NOT REGISTERED"})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = pharmacyName, onValueChange = { pharmacyName = it }, label = { Text("Pharmacy Business Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = pharmacistName, onValueChange = { pharmacistName = it }, label = { Text("Supervising Pharmacist") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = tmdaLicense, onValueChange = { tmdaLicense = it }, label = { Text("TMDA Pharmacy License #") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = { onSubmitCredentials("pharmacy", pharmacistName, pharmacyName, tmdaLicense, "Dispensing Pharmacy", "Dar es Salaam") },
                        enabled = pharmacyName.isNotBlank() && pharmacistName.isNotBlank() && tmdaLicense.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Submit Pharmacy Verification")
                    }
                }
            }
        }

        item {
            SectionHeader("Prescription & Medicine Orders")
        }

        items(orders, key = { it.id }) { ord ->
            Card(shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${ord.medicineName} x${ord.quantity} • ${ord.pharmacyName}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("Child: ${ord.childName} • Mode: ${ord.deliveryMode} • Status: ${ord.status}", style = MaterialTheme.typography.bodySmall)
                    if (ord.requiresPrescription) {
                        Text("Rx Verification Note: ${ord.prescriptionNote}", style = MaterialTheme.typography.labelMedium, color = RiskOrange)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onAdvanceOrder(ord.id, "preparing") },
                            enabled = ord.status == "pending_verification",
                            modifier = Modifier.weight(1f)
                        ) { Text("Verify & Prep") }
                        Button(
                            onClick = { onAdvanceOrder(ord.id, "completed") },
                            enabled = ord.status != "completed",
                            modifier = Modifier.weight(1f)
                        ) { Text(if (ord.status == "completed") "Completed" else "Mark Delivered") }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminPortal(
    isAdminUser: Boolean,
    children: List<ChildProfile>,
    assessments: List<HealthAssessment>,
    consultations: List<ConsultationRecord>,
    pharmacyOrders: List<PharmacyOrder>,
    onPublishBulletin: (String, String, String, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var source by remember { mutableStateOf("Ministry of Health Tanzania") }
    var category by remember { mutableStateOf("Vaccination") }
    var summary by remember { mutableStateOf("") }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            SectionHeader("Central Administration & Health Analytics", "Aggregated privacy-protected metrics • Tanzania & Global")
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatTile("Registered Children", children.size.toString(), PrimaryBlue, Modifier.weight(1f))
                StatTile("AI Assessments", assessments.size.toString(), HealthcareTeal, Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatTile("Consultations", consultations.size.toString(), PrimaryBlue, Modifier.weight(1f))
                StatTile("Emergency Red Flags", assessments.count { it.riskLevel == "RED" }.toString(), RiskRed, Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatTile("Pharmacy Orders", pharmacyOrders.size.toString(), RiskGreen, Modifier.weight(1f))
                StatTile("Active Regions", "TZ • KE • UG • Global", HealthcareTeal, Modifier.weight(1f))
            }
        }

        item {
            Card(shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isAdminUser) "Publish Verified Official Health Bulletin (Admin Authorized)"
                        else "Official Health Content CMS (Admin Role Required to Publish)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isAdminUser) RiskGreen else PrimaryBlue
                    )
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Bulletin Title") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = source, onValueChange = { source = it }, label = { Text("Official Source") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = summary, onValueChange = { summary = it }, label = { Text("Verified Guidance Summary") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            onPublishBulletin(title, source, "2026-11-24", category, summary, "en")
                            title = ""
                            summary = ""
                        },
                        enabled = isAdminUser && title.isNotBlank() && source.isNotBlank() && category.isNotBlank() && summary.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Publish Official Bulletin")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatTile(
    label: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = accent.copy(alpha = 0.1f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = accent)
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
