package com.example.ui

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppLanguage
import com.example.core.CryAudioRecording
import com.example.core.GlobalCountryCatalog
import com.example.data.AgeGroup
import com.example.data.CareNotification
import com.example.data.ChildProfile
import com.example.data.ConsultationMessage
import com.example.data.ConsultationRecord
import com.example.data.CryAnalysisResult
import com.example.data.GrowthMeasurement
import com.example.data.HealthAssessment
import com.example.data.OfficialHealthBulletin
import com.example.data.PediatricSpecialist
import com.example.data.PharmacyListing
import com.example.data.PharmacyOrder
import com.example.data.ProviderApplication
import com.example.data.RiskLevel
import com.example.data.SymptomAssessmentResult
import com.example.data.TotoAiService
import com.example.data.TotoRepository
import com.example.data.UserProfile
import com.example.data.VaccinationRecord
import com.example.data.WorkspaceRole
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface AiTaskState<out T> {
    data object Idle : AiTaskState<Nothing>
    data object Loading : AiTaskState<Nothing>
    data class Success<T>(val data: T) : AiTaskState<T>
    data class Error(val message: String) : AiTaskState<Nothing>
}

data class AssistantChatItem(
    val id: String,
    val fromUser: Boolean,
    val text: String,
    val isStreaming: Boolean = false
)

class TotoViewModel(
    private val repository: TotoRepository,
    private val aiService: TotoAiService,
    val currentUserId: String,
    val userEmail: String,
    val userDisplayName: String
) : ViewModel() {

    private fun <T> Flow<T>.toUiState(label: String): StateFlow<UiState<T>> =
        map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $label", rootError)
                emit(UiState.Error(rootError.message ?: "Failed to load $label"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    val userProfile: StateFlow<UiState<UserProfile?>> =
        repository.observeUserProfile(currentUserId).toUiState("userProfile")

    val children: StateFlow<UiState<List<ChildProfile>>> =
        repository.observeChildren(currentUserId).toUiState("children")

    val vaccinations: StateFlow<UiState<List<VaccinationRecord>>> =
        repository.observeVaccinations(currentUserId).toUiState("vaccinations")

    val growthLogs: StateFlow<UiState<List<GrowthMeasurement>>> =
        repository.observeGrowthLogs(currentUserId).toUiState("growthLogs")

    val assessments: StateFlow<UiState<List<HealthAssessment>>> =
        repository.observeAssessments(currentUserId).toUiState("assessments")

    val notifications: StateFlow<UiState<List<CareNotification>>> =
        repository.observeNotifications(currentUserId).toUiState("notifications")

    val consultations: StateFlow<UiState<List<ConsultationRecord>>> =
        repository.observeConsultations(currentUserId).toUiState("consultations")

    val pharmacyOrders: StateFlow<UiState<List<PharmacyOrder>>> =
        repository.observePharmacyOrders(currentUserId).toUiState("pharmacyOrders")

    val providerApplication: StateFlow<UiState<ProviderApplication?>> =
        repository.observeMyProviderApplication(currentUserId).toUiState("providerApplication")

    val publishedBulletins: StateFlow<UiState<List<OfficialHealthBulletin>>> =
        repository.observePublishedBulletins(currentUserId).toUiState("publishedBulletins")

    private val _selectedChildId = MutableStateFlow<String?>(null)
    val selectedChildId: StateFlow<String?> = _selectedChildId.asStateFlow()

    private val _languageOverride = MutableStateFlow<AppLanguage?>(null)
    private val _countryCodeOverride = MutableStateFlow<String?>(null)
    private val _workspaceRole = MutableStateFlow(WorkspaceRole.PARENT)
    val workspaceRole: StateFlow<WorkspaceRole> = _workspaceRole.asStateFlow()

    private val _symptomState = MutableStateFlow<AiTaskState<SymptomAssessmentResult>>(AiTaskState.Idle)
    val symptomState: StateFlow<AiTaskState<SymptomAssessmentResult>> = _symptomState.asStateFlow()

    private val _cryState = MutableStateFlow<AiTaskState<CryAnalysisResult>>(AiTaskState.Idle)
    val cryState: StateFlow<AiTaskState<CryAnalysisResult>> = _cryState.asStateFlow()

    private val _assistantMessages = MutableStateFlow<List<AssistantChatItem>>(emptyList())
    val assistantMessages: StateFlow<List<AssistantChatItem>> = _assistantMessages.asStateFlow()

    private val _assistantBusy = MutableStateFlow(false)
    val assistantBusy: StateFlow<Boolean> = _assistantBusy.asStateFlow()

    private val _activeConsultationMessages = MutableStateFlow<List<ConsultationMessage>>(emptyList())
    val activeConsultationMessages: StateFlow<List<ConsultationMessage>> = _activeConsultationMessages.asStateFlow()
    private var messageObserveJob: Job? = null

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureUserProfile(
                fullName = userDisplayName.ifBlank { "TOTOCARE Parent" },
                email = userEmail
            )
        }
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun selectChild(childId: String) {
        _selectedChildId.value = childId
    }

    fun currentLanguage(profile: UserProfile?): AppLanguage =
        _languageOverride.value ?: AppLanguage.fromCode(profile?.language ?: "en")

    fun currentCountryCode(profile: UserProfile?): String =
        _countryCodeOverride.value ?: profile?.countryCode?.ifBlank { "TZ" } ?: "TZ"

    fun toggleLanguage(profile: UserProfile?) {
        val next = if (currentLanguage(profile) == AppLanguage.ENGLISH) {
            AppLanguage.KISWAHILI
        } else {
            AppLanguage.ENGLISH
        }
        _languageOverride.value = next
        if (profile != null) {
            viewModelScope.launch {
                repository.updateUserSettings(
                    fullName = profile.fullName,
                    phone = profile.phone,
                    caregiverRole = profile.caregiverRole,
                    language = next.code,
                    countryCode = profile.countryCode,
                    workspaceRole = profile.workspaceRole,
                    emergencyContactName = profile.emergencyContactName,
                    emergencyContactPhone = profile.emergencyContactPhone,
                    twoFactorEnabled = profile.twoFactorEnabled,
                    notificationsEnabled = profile.notificationsEnabled
                )
            }
        }
    }

    fun switchWorkspaceRole(role: WorkspaceRole, profile: UserProfile?) {
        _workspaceRole.value = role
        if (profile != null) {
            viewModelScope.launch {
                repository.updateUserSettings(
                    fullName = profile.fullName,
                    phone = profile.phone,
                    caregiverRole = profile.caregiverRole,
                    language = profile.language,
                    countryCode = profile.countryCode,
                    workspaceRole = role.code,
                    emergencyContactName = profile.emergencyContactName,
                    emergencyContactPhone = profile.emergencyContactPhone,
                    twoFactorEnabled = profile.twoFactorEnabled,
                    notificationsEnabled = profile.notificationsEnabled
                )
            }
        }
    }

    fun saveAccountSettings(
        profile: UserProfile?,
        fullName: String,
        phone: String,
        caregiverRole: String,
        countryCode: String,
        emergencyContactName: String,
        emergencyContactPhone: String,
        twoFactorEnabled: Boolean,
        notificationsEnabled: Boolean
    ) {
        _countryCodeOverride.value = countryCode
        viewModelScope.launch {
            val lang = currentLanguage(profile).code
            val role = _workspaceRole.value.code
            val res = repository.updateUserSettings(
                fullName = fullName,
                phone = phone,
                caregiverRole = caregiverRole,
                language = lang,
                countryCode = countryCode,
                workspaceRole = role,
                emergencyContactName = emergencyContactName,
                emergencyContactPhone = emergencyContactPhone,
                twoFactorEnabled = twoFactorEnabled,
                notificationsEnabled = notificationsEnabled
            )
            _statusBanner.value = res.fold(
                onSuccess = { "Account & security preferences saved (${GlobalCountryCatalog.byCode(countryCode).name})." },
                onFailure = { it.localizedMessage ?: "Failed to save account settings." }
            )
        }
    }

    fun registerChild(child: ChildProfile) {
        viewModelScope.launch {
            val res = repository.addChildProfile(child, seedTanzaniaEpi = true)
            _statusBanner.value = res.fold(
                onSuccess = { id ->
                    _selectedChildId.value = id
                    "Child profile registered with Tanzania EPI vaccination tracker."
                },
                onFailure = { it.localizedMessage ?: "Could not register child." }
            )
        }
    }

    fun updateChildMedical(
        childId: String,
        allergies: String,
        conditions: String,
        medications: String,
        emergencyName: String,
        emergencyPhone: String,
        photoUri: String
    ) {
        viewModelScope.launch {
            val res = repository.updateChildMedicalDetails(
                childId, allergies, conditions, medications, emergencyName, emergencyPhone, photoUri
            )
            _statusBanner.value = res.fold(
                onSuccess = { "Child medical record updated." },
                onFailure = { it.localizedMessage ?: "Failed to update medical record." }
            )
        }
    }

    fun updateVaccineStatus(vaccinationId: String, status: String, dateText: String, clinic: String) {
        viewModelScope.launch {
            val res = repository.updateVaccinationStatus(vaccinationId, status, dateText, clinic)
            _statusBanner.value = res.fold(
                onSuccess = { "Vaccination status updated." },
                onFailure = { it.localizedMessage ?: "Failed to update vaccination." }
            )
        }
    }

    fun addGrowthLog(
        child: ChildProfile,
        weightKg: Double,
        heightCm: Double,
        headCm: Double,
        dateText: String,
        milestone: String
    ) {
        viewModelScope.launch {
            val res = repository.addGrowthMeasurement(
                child.id, child.fullName, weightKg, heightCm, headCm, dateText, milestone
            )
            _statusBanner.value = res.fold(
                onSuccess = { "Growth measurement recorded for ${child.fullName}." },
                onFailure = { it.localizedMessage ?: "Failed to log measurement." }
            )
        }
    }

    fun runSymptomAssessment(
        child: ChildProfile?,
        ageGroup: AgeGroup,
        symptomsText: String,
        selectedSymptoms: List<String>,
        guidedAnswers: Map<String, String>,
        language: AppLanguage,
        attachedBitmap: Bitmap?
    ) {
        viewModelScope.launch {
            _symptomState.value = AiTaskState.Loading
            val result = aiService.assessChildSymptoms(
                child = child,
                ageGroup = ageGroup,
                symptomsText = symptomsText,
                selectedSymptoms = selectedSymptoms,
                guidedAnswers = guidedAnswers,
                language = language,
                attachedImage = attachedBitmap
            )
            result.fold(
                onSuccess = { assessment ->
                    _symptomState.value = AiTaskState.Success(assessment)
                    if (child != null) {
                        val summary = (selectedSymptoms + listOfNotNull(symptomsText.takeIf { it.isNotBlank() }))
                            .joinToString(", ")
                            .ifBlank { "Guided symptom check" }
                        repository.saveHealthAssessment(
                            childId = child.id,
                            childName = child.fullName,
                            kind = "symptom",
                            ageGroup = ageGroup.code,
                            symptomsSummary = summary,
                            riskLevel = assessment.riskLevel.code,
                            aiExplanation = assessment.possibleExplanations,
                            nextSteps = assessment.nextSteps,
                            emergencyTriggered = assessment.riskLevel == RiskLevel.RED
                        )
                    }
                },
                onFailure = { err ->
                    _symptomState.value = AiTaskState.Error(err.localizedMessage ?: "AI assessment failed.")
                }
            )
        }
    }

    fun runBabyCryAnalysis(
        child: ChildProfile?,
        recording: CryAudioRecording,
        warningAnswers: Map<String, String>,
        notes: String,
        language: AppLanguage
    ) {
        viewModelScope.launch {
            _cryState.value = AiTaskState.Loading
            val result = aiService.analyzeBabyCry(
                child = child,
                recording = recording,
                extraWarningAnswers = warningAnswers,
                parentNotes = notes,
                language = language
            )
            result.fold(
                onSuccess = { cry ->
                    _cryState.value = AiTaskState.Success(cry)
                    if (child != null) {
                        repository.saveHealthAssessment(
                            childId = child.id,
                            childName = child.fullName,
                            kind = "cry",
                            ageGroup = child.ageGroup,
                            symptomsSummary = "Cry audio (${"%.1f".format(recording.durationSeconds)}s, ~${recording.estimatedPitchHz}Hz): ${cry.primaryPatterns.joinToString(", ")}",
                            riskLevel = cry.riskLevel.code,
                            aiExplanation = "${cry.acousticSummary}\n\n${cry.uncertaintyNotice}",
                            nextSteps = cry.recommendedNextSteps,
                            emergencyTriggered = cry.riskLevel == RiskLevel.RED
                        )
                    }
                },
                onFailure = { err ->
                    _cryState.value = AiTaskState.Error(err.localizedMessage ?: "Cry analysis failed.")
                }
            )
        }
    }

    fun sendAssistantMessage(question: String, child: ChildProfile?, language: AppLanguage) {
        val clean = question.trim()
        if (clean.isEmpty() || _assistantBusy.value) return
        val userMsgId = "u_${System.currentTimeMillis()}"
        val botMsgId = "b_${System.currentTimeMillis() + 1}"
        _assistantMessages.value = _assistantMessages.value +
            AssistantChatItem(userMsgId, fromUser = true, text = clean) +
            AssistantChatItem(botMsgId, fromUser = false, text = "", isStreaming = true)
        _assistantBusy.value = true

        viewModelScope.launch {
            try {
                aiService.streamHealthAssistant(clean, child, language).collect { partial ->
                    _assistantMessages.value = _assistantMessages.value.map { msg ->
                        if (msg.id == botMsgId) msg.copy(text = partial, isStreaming = true) else msg
                    }
                }
                _assistantMessages.value = _assistantMessages.value.map { msg ->
                    if (msg.id == botMsgId) msg.copy(isStreaming = false) else msg
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Assistant stream failed", e)
                _assistantMessages.value = _assistantMessages.value.map { msg ->
                    if (msg.id == botMsgId) {
                        msg.copy(
                            text = "Error: ${e.localizedMessage ?: "Unable to reach AI Assistant right now."}",
                            isStreaming = false
                        )
                    } else msg
                }
            } finally {
                _assistantBusy.value = false
            }
        }
    }

    fun bookConsultation(
        parentName: String,
        child: ChildProfile,
        doctor: PediatricSpecialist,
        mode: String,
        slot: String,
        symptoms: String,
        attachmentLabel: String
    ) {
        viewModelScope.launch {
            val res = repository.createConsultation(
                parentName, child.id, child.fullName, doctor, mode, slot, symptoms, attachmentLabel
            )
            _statusBanner.value = res.fold(
                onSuccess = { "Consultation booked with ${doctor.fullName}." },
                onFailure = { it.localizedMessage ?: "Failed to book consultation." }
            )
        }
    }

    fun observeConsultationThread(consultationId: String) {
        messageObserveJob?.cancel()
        messageObserveJob = viewModelScope.launch {
            repository.observeConsultationMessages(consultationId, currentUserId)
                .catch { error ->
                    if (error is CancellationException) throw error
                    Log.w(TAG, "Message thread error", error)
                }
                .collect { _activeConsultationMessages.value = it }
        }
    }

    fun sendConsultationChatMessage(
        consultationId: String,
        senderName: String,
        senderRole: String,
        body: String,
        attachmentLabel: String = ""
    ) {
        if (body.isBlank()) return
        viewModelScope.launch {
            val res = repository.sendConsultationMessage(
                consultationId, senderName, senderRole, body, attachmentLabel
            )
            if (res.isFailure) {
                _statusBanner.value = res.exceptionOrNull()?.localizedMessage ?: "Message failed."
            }
        }
    }

    fun updateConsultationAsDoctor(
        consultationId: String,
        status: String,
        notes: String,
        prescription: String,
        referral: String
    ) {
        viewModelScope.launch {
            val res = repository.updateConsultationClinicalRecord(
                consultationId, status, notes, prescription, referral
            )
            _statusBanner.value = res.fold(
                onSuccess = { "Consultation notes, prescription, and referral saved." },
                onFailure = { it.localizedMessage ?: "Update failed." }
            )
        }
    }

    fun placePharmacyOrder(
        parentName: String,
        childName: String,
        listing: PharmacyListing,
        quantity: Long,
        prescriptionNote: String,
        deliveryMode: String,
        address: String
    ) {
        viewModelScope.launch {
            val res = repository.placePharmacyOrder(
                parentName, childName, listing, quantity, prescriptionNote, deliveryMode, address
            )
            _statusBanner.value = res.fold(
                onSuccess = { "Order sent to ${listing.pharmacyName}." },
                onFailure = { it.localizedMessage ?: "Order failed." }
            )
        }
    }

    fun advancePharmacyOrder(orderId: String, nextStatus: String) {
        viewModelScope.launch {
            val res = repository.updatePharmacyOrderStatus(orderId, nextStatus)
            _statusBanner.value = res.fold(
                onSuccess = { "Order status updated to $nextStatus." },
                onFailure = { it.localizedMessage ?: "Order update failed." }
            )
        }
    }

    fun submitProviderCredentials(
        type: String,
        name: String,
        facility: String,
        license: String,
        specialty: String,
        region: String
    ) {
        viewModelScope.launch {
            val res = repository.submitProviderApplication(type, name, facility, license, specialty, region)
            _statusBanner.value = res.fold(
                onSuccess = { "Verification application submitted for clinical review." },
                onFailure = { it.localizedMessage ?: "Submission failed." }
            )
        }
    }

    fun publishOfficialBulletin(
        title: String,
        source: String,
        date: String,
        category: String,
        summary: String,
        languageCode: String
    ) {
        viewModelScope.launch {
            val res = repository.publishHealthBulletin(title, source, date, category, summary, languageCode)
            _statusBanner.value = res.fold(
                onSuccess = { "Official health bulletin published." },
                onFailure = { it.localizedMessage ?: "Only verified platform administrators can publish bulletins." }
            )
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun isAdminEmail(): Boolean = userEmail.equals("georgemihotz@gmail.com", ignoreCase = true)

    private companion object {
        const val TAG = "TotoViewModel"
    }
}
