package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF1677C8)
val PrimaryBlueDark = Color(0xFF0E5A9E)
val HealthcareTeal = Color(0xFF16B8A6)
val HealthcareTealDark = Color(0xFF0F8E80)
val SoftLightBlue = Color(0xFFEAF5FC)
val SoftTealTint = Color(0xFFE3F7F4)
val PureWhite = Color(0xFFFFFFFF)
val OffWhiteCanvas = Color(0xFFF6FAFD)
val DarkNavy = Color(0xFF17324D)
val SlateMuted = Color(0xFF536B82)
val DividerBlue = Color(0xFFD6E6F2)

// Emergency Risk Classification Palette
val RiskRed = Color(0xFFD32F2F)
val RiskRedContainer = Color(0xFFFDECEC)
val RiskOrange = Color(0xFFE65100)
val RiskOrangeContainer = Color(0xFFFFF3E0)
val RiskYellow = Color(0xFF9A6700)
val RiskYellowContainer = Color(0xFFFFF8E1)
val RiskGreen = Color(0xFF1B8A5A)
val RiskGreenContainer = Color(0xFFE8F5E9)

// Dark mode equivalents
val DarkBg = Color(0xFF0D1D2C)
val DarkSurface = Color(0xFF14283C)
val DarkSurfaceVariant = Color(0xFF1D364F)
