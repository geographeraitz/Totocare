package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocalHospital
import androidx.compose.material.icons.outlined.MedicalServices
import androidx.compose.material.icons.outlined.Vaccines
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.AppLanguage
import com.example.core.GlobalCountryCatalog
import com.example.core.signOut
import com.example.core.stringsFor
import com.example.data.AgeGroup
import com.example.data.ChildProfile
import com.example.ui.screens.AssessHubScreen
import com.example.ui.screens.CareServicesScreen
import com.example.ui.screens.ClinicRecordsScreen
import com.example.ui.screens.EmergencyAssistanceSheet
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PortalsScreen
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RiskRed

object TotoRoutes {
    const val HOME = "home"
    const val ASSESS = "assess"
    const val CLINIC = "clinic"
    const val CARE = "care"
    const val PORTALS = "portals"
}

private data class NavItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TotoAppShell(
    viewModel: TotoViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val profileState by viewModel.userProfile.collectAsStateWithLifecycle()
    val childrenState by viewModel.children.collectAsStateWithLifecycle()
    val vaccinationsState by viewModel.vaccinations.collectAsStateWithLifecycle()
    val growthState by viewModel.growthLogs.collectAsStateWithLifecycle()
    val assessmentsState by viewModel.assessments.collectAsStateWithLifecycle()
    val notificationsState by viewModel.notifications.collectAsStateWithLifecycle()
    val consultationsState by viewModel.consultations.collectAsStateWithLifecycle()
    val activeConsultMessages by viewModel.activeConsultationMessages.collectAsStateWithLifecycle()
    val pharmacyOrdersState by viewModel.pharmacyOrders.collectAsStateWithLifecycle()
    val providerAppState by viewModel.providerApplication.collectAsStateWithLifecycle()
    val bulletinsState by viewModel.publishedBulletins.collectAsStateWithLifecycle()

    val selectedChildId by viewModel.selectedChildId.collectAsStateWithLifecycle()
    val workspaceRole by viewModel.workspaceRole.collectAsStateWithLifecycle()
    val symptomState by viewModel.symptomState.collectAsStateWithLifecycle()
    val cryState by viewModel.cryState.collectAsStateWithLifecycle()
    val assistantMessages by viewModel.assistantMessages.collectAsStateWithLifecycle()
    val assistantBusy by viewModel.assistantBusy.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    val userProfile = (profileState as? UiState.Success)?.data
    val children = (childrenState as? UiState.Success)?.data.orEmpty()
    val vaccinations = (vaccinationsState as? UiState.Success)?.data.orEmpty()
    val growthLogs = (growthState as? UiState.Success)?.data.orEmpty()
    val assessments = (assessmentsState as? UiState.Success)?.data.orEmpty()
    val notifications = (notificationsState as? UiState.Success)?.data.orEmpty()
    val consultations = (consultationsState as? UiState.Success)?.data.orEmpty()
    val pharmacyOrders = (pharmacyOrdersState as? UiState.Success)?.data.orEmpty()
    val providerApplication = (providerAppState as? UiState.Success)?.data
    val bulletins = (bulletinsState as? UiState.Success)?.data.orEmpty()

    val activeChild = children.firstOrNull { it.id == selectedChildId } ?: children.firstOrNull()
    val language = viewModel.currentLanguage(userProfile)
    val country = GlobalCountryCatalog.byCode(viewModel.currentCountryCode(userProfile))
    val strings = stringsFor(language)

    var showEmergencySheet by remember { mutableStateOf(false) }
    var showAddChildDialog by remember { mutableStateOf(false) }
    var assessTab by remember { mutableIntStateOf(0) }
    var clinicTab by remember { mutableIntStateOf(0) }
    var careTab by remember { mutableIntStateOf(0) }
    var gpsCoordinates by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var prefillConsultNotes by remember { mutableStateOf("") }

    val notifPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(statusBanner) {
        val msg = statusBanner
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    val navItems = listOf(
        NavItem(TotoRoutes.HOME, strings.navHome, Icons.Filled.Home, Icons.Outlined.Home),
        NavItem(TotoRoutes.ASSESS, strings.navAssess, Icons.Filled.MedicalServices, Icons.Outlined.MedicalServices),
        NavItem(TotoRoutes.CLINIC, strings.navClinic, Icons.Filled.Vaccines, Icons.Outlined.Vaccines),
        NavItem(TotoRoutes.CARE, strings.navCare, Icons.Filled.LocalHospital, Icons.Outlined.LocalHospital),
        NavItem(TotoRoutes.PORTALS, strings.navPortals, Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings)
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: TotoRoutes.HOME

    fun navigateSingleTop(route: String) {
        navController.navigate(route) {
            popUpTo(TotoRoutes.HOME) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Psychology, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("TOTOCARE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("${country.flagEmoji} ${country.name}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    },
                    actions = {
                        TextButton(
                            onClick = { viewModel.toggleLanguage(userProfile) },
                            modifier = Modifier.testTag("language_toggle_button")
                        ) {
                            Text(
                                text = if (language == AppLanguage.ENGLISH) "SW" else "EN",
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Button(
                            onClick = { showEmergencySheet = true },
                            colors = ButtonDefaults.buttonColors(containerColor = RiskRed),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .padding(end = 10.dp)
                                .testTag("topbar_sos_button")
                        ) {
                            Icon(Icons.Filled.Emergency, contentDescription = strings.sosEmergency, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.sosEmergency, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar {
                        navItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateSingleTop(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label, maxLines = 1) }
                            )
                        }
                    }
                }
            },
            contentWindowInsets = WindowInsets(0, 0, 0, 0)
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail {
                        navItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateSingleTop(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label) }
                            )
                        }
                    }
                }

                Box(
                    contentAlignment = Alignment.TopCenter,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(modifier = Modifier.widthIn(max = 860.dp).fillMaxSize()) {
                        if (profileState is UiState.Loading && childrenState is UiState.Loading) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                CircularProgressIndicator()
                            }
                        } else {
                            NavHost(
                                navController = navController,
                                startDestination = TotoRoutes.HOME
                            ) {
                                composable(TotoRoutes.HOME) {
                                    HomeScreen(
                                        parentName = userProfile?.fullName ?: viewModel.userDisplayName.ifBlank { "Parent" },
                                        country = country,
                                        language = language,
                                        strings = strings,
                                        children = children,
                                        activeChild = activeChild,
                                        vaccinations = vaccinations,
                                        assessments = assessments,
                                        notifications = notifications,
                                        onSelectChild = viewModel::selectChild,
                                        onOpenAddChild = { showAddChildDialog = true },
                                        onOpenEmergency = { showEmergencySheet = true },
                                        onNavigateAssess = { tab ->
                                            assessTab = tab
                                            navigateSingleTop(TotoRoutes.ASSESS)
                                        },
                                        onNavigateClinic = { tab ->
                                            clinicTab = tab
                                            navigateSingleTop(TotoRoutes.CLINIC)
                                        },
                                        onNavigateServices = { tab ->
                                            careTab = tab
                                            navigateSingleTop(TotoRoutes.CARE)
                                        },
                                        onMarkNotificationRead = viewModel::markNotificationRead
                                    )
                                }

                                composable(TotoRoutes.ASSESS) {
                                    AssessHubScreen(
                                        selectedTab = assessTab,
                                        onSelectTab = { assessTab = it },
                                        activeChild = activeChild,
                                        language = language,
                                        strings = strings,
                                        symptomState = symptomState,
                                        cryState = cryState,
                                        assistantMessages = assistantMessages,
                                        assistantBusy = assistantBusy,
                                        onRunSymptomAssessment = { age, text, chips, answers, bmp ->
                                            viewModel.runSymptomAssessment(activeChild, age, text, chips, answers, language, bmp)
                                        },
                                        onRunCryAnalysis = { rec, answers, notes ->
                                            viewModel.runBabyCryAnalysis(activeChild, rec, answers, notes, language)
                                        },
                                        onSendAssistantMessage = { q ->
                                            viewModel.sendAssistantMessage(q, activeChild, language)
                                        },
                                        onOpenEmergency = { showEmergencySheet = true },
                                        onEscalateToDoctor = { summary ->
                                            prefillConsultNotes = summary
                                            careTab = 1
                                            navigateSingleTop(TotoRoutes.CARE)
                                        }
                                    )
                                }

                                composable(TotoRoutes.CLINIC) {
                                    ClinicRecordsScreen(
                                        selectedTab = clinicTab,
                                        onSelectTab = { clinicTab = it },
                                        country = country,
                                        language = language,
                                        strings = strings,
                                        children = children,
                                        activeChild = activeChild,
                                        vaccinations = vaccinations,
                                        growthLogs = growthLogs,
                                        assessments = assessments,
                                        consultations = consultations,
                                        onSelectChild = viewModel::selectChild,
                                        onOpenAddChild = { showAddChildDialog = true },
                                        onUpdateChildMedical = viewModel::updateChildMedical,
                                        onUpdateVaccineStatus = viewModel::updateVaccineStatus,
                                        onAddGrowthLog = viewModel::addGrowthLog
                                    )
                                }

                                composable(TotoRoutes.CARE) {
                                    CareServicesScreen(
                                        selectedTab = careTab,
                                        onSelectTab = { careTab = it },
                                        parentName = userProfile?.fullName ?: "Parent",
                                        country = country,
                                        language = language,
                                        strings = strings,
                                        activeChild = activeChild,
                                        gpsCoordinates = gpsCoordinates,
                                        onGpsUpdated = { lat, lon -> gpsCoordinates = lat to lon },
                                        consultations = consultations,
                                        activeMessages = activeConsultMessages,
                                        pharmacyOrders = pharmacyOrders,
                                        bulletins = bulletins,
                                        prefillConsultNotes = prefillConsultNotes,
                                        onBookConsultation = { child, doc, mode, slot, notes, attach ->
                                            viewModel.bookConsultation(
                                                userProfile?.fullName ?: "Parent",
                                                child, doc, mode, slot, notes, attach
                                            )
                                        },
                                        onOpenConsultationChat = viewModel::observeConsultationThread,
                                        onSendConsultationMessage = { cid, msg ->
                                            viewModel.sendConsultationChatMessage(
                                                cid,
                                                userProfile?.fullName ?: "Parent",
                                                "parent",
                                                msg
                                            )
                                        },
                                        onPlacePharmacyOrder = { childName, listing, qty, rx, mode, addr ->
                                            viewModel.placePharmacyOrder(
                                                userProfile?.fullName ?: "Parent",
                                                childName, listing, qty, rx, mode, addr
                                            )
                                        }
                                    )
                                }

                                composable(TotoRoutes.PORTALS) {
                                    PortalsScreen(
                                        workspaceRole = workspaceRole,
                                        onSwitchWorkspaceRole = { r -> viewModel.switchWorkspaceRole(r, userProfile) },
                                        userProfile = userProfile,
                                        userEmail = viewModel.userEmail,
                                        isAdminUser = viewModel.isAdminEmail(),
                                        language = language,
                                        children = children,
                                        assessments = assessments,
                                        consultations = consultations,
                                        pharmacyOrders = pharmacyOrders,
                                        providerApplication = providerApplication,
                                        onSaveAccountSettings = { name, phone, role, cCode, eName, ePhone, tfa, notifs ->
                                            viewModel.saveAccountSettings(userProfile, name, phone, role, cCode, eName, ePhone, tfa, notifs)
                                        },
                                        onSignOut = {
                                            signOut(credentialManager, scope)
                                        },
                                        onSubmitProviderCredentials = viewModel::submitProviderCredentials,
                                        onUpdateConsultationDoctor = viewModel::updateConsultationAsDoctor,
                                        onAdvancePharmacyOrder = viewModel::advancePharmacyOrder,
                                        onPublishBulletin = viewModel::publishOfficialBulletin
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEmergencySheet) {
        EmergencyAssistanceSheet(
            child = activeChild,
            country = country,
            language = language,
            gpsCoordinates = gpsCoordinates,
            onDismiss = { showEmergencySheet = false },
            onEscalateToDoctor = {
                careTab = 1
                navigateSingleTop(TotoRoutes.CARE)
            }
        )
    }

    if (showAddChildDialog) {
        RegisterChildDialog(
            defaultEmergencyName = userProfile?.fullName ?: "",
            defaultEmergencyPhone = userProfile?.phone ?: "",
            onDismiss = { showAddChildDialog = false },
            onSave = { child ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val granted = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!granted) {
                        notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                viewModel.registerChild(child)
                showAddChildDialog = false
            }
        )
    }
}

@Composable
private fun RegisterChildDialog(
    defaultEmergencyName: String,
    defaultEmergencyPhone: String,
    onDismiss: () -> Unit,
    onSave: (ChildProfile) -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var dobText by remember { mutableStateOf("2025-05-15") }
    var ageMonthsText by remember { mutableStateOf("18") }
    var gender by remember { mutableStateOf("Female") }
    var birthWeightText by remember { mutableStateOf("3.2") }
    var bloodGroup by remember { mutableStateOf("O+") }
    var location by remember { mutableStateOf("Kinondoni, Dar es Salaam") }
    var allergies by remember { mutableStateOf("") }
    var conditions by remember { mutableStateOf("") }
    var emergencyName by remember { mutableStateOf(defaultEmergencyName) }
    var emergencyPhone by remember { mutableStateOf(defaultEmergencyPhone) }
    var photoUri by remember { mutableStateOf("") }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) photoUri = uri.toString()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Register Child Medical Profile") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedButton(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (photoUri.isBlank()) "Upload Child Photo (Optional)" else "Photo Selected")
                }
                OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Child Full Name *") }, modifier = Modifier.fillMaxWidth().testTag("child_name_input"))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = dobText, onValueChange = { dobText = it }, label = { Text("DOB (YYYY-MM-DD)") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = ageMonthsText, onValueChange = { ageMonthsText = it }, label = { Text("Age (Months)") }, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Female", "Male").forEach { g ->
                        FilterChip(selected = gender == g, onClick = { gender = g }, label = { Text(g) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = birthWeightText, onValueChange = { birthWeightText = it }, label = { Text("Birth Wt (kg)") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = bloodGroup, onValueChange = { bloodGroup = it }, label = { Text("Blood Group") }, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("District / City") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = allergies, onValueChange = { allergies = it }, label = { Text("Allergies (if any)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = conditions, onValueChange = { conditions = it }, label = { Text("Previous Illnesses / Conditions") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = emergencyName, onValueChange = { emergencyName = it }, label = { Text("Emergency Contact Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = emergencyPhone, onValueChange = { emergencyPhone = it }, label = { Text("Emergency Contact Phone") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                enabled = fullName.isNotBlank(),
                onClick = {
                    val months = (ageMonthsText.toLongOrNull() ?: 12L).coerceIn(0L, 168L)
                    onSave(
                        ChildProfile(
                            fullName = fullName,
                            dobText = dobText,
                            ageMonths = months,
                            ageGroup = AgeGroup.fromMonths(months).code,
                            gender = gender,
                            birthWeightKg = birthWeightText.toDoubleOrNull() ?: 3.2,
                            bloodGroup = bloodGroup,
                            location = location,
                            allergies = allergies,
                            existingConditions = conditions,
                            emergencyContactName = emergencyName,
                            emergencyContactPhone = emergencyPhone,
                            photoUri = photoUri
                        )
                    )
                },
                modifier = Modifier.testTag("confirm_register_child_button")
            ) {
                Text("Register")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
