package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.AppLanguage
import com.example.core.CountryConfig
import com.example.core.TotoStrings
import com.example.data.ChildProfile
import com.example.data.ConsultationRecord
import com.example.data.GrowthMeasurement
import com.example.data.HealthAssessment
import com.example.data.RiskLevel
import com.example.data.VaccinationRecord
import com.example.ui.components.ChildSelectorBar
import com.example.ui.components.EmptyNoticeCard
import com.example.ui.components.GrowthProgressChart
import com.example.ui.components.RiskLevelBadge
import com.example.ui.components.SectionHeader
import com.example.ui.theme.HealthcareTeal
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RiskGreen
import com.example.ui.theme.RiskGreenContainer
import com.example.ui.theme.RiskOrange
import com.example.ui.theme.RiskRed
import com.example.ui.theme.SoftLightBlue

@Composable
fun ClinicRecordsScreen(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    country: CountryConfig,
    language: AppLanguage,
    strings: TotoStrings,
    children: List<ChildProfile>,
    activeChild: ChildProfile?,
    vaccinations: List<VaccinationRecord>,
    growthLogs: List<GrowthMeasurement>,
    assessments: List<HealthAssessment>,
    consultations: List<ConsultationRecord>,
    onSelectChild: (String) -> Unit,
    onOpenAddChild: () -> Unit,
    onUpdateChildMedical: (String, String, String, String, String, String, String) -> Unit,
    onUpdateVaccineStatus: (String, String, String, String) -> Unit,
    onAddGrowthLog: (ChildProfile, Double, Double, Double, String, String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            ChildSelectorBar(
                children = children,
                selectedChildId = activeChild?.id,
                onSelectChild = onSelectChild,
                onAddChildClick = onOpenAddChild,
                addLabel = strings.addChild
            )
        }

        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { onSelectTab(0) }, text = { Text(strings.medicalRecords, maxLines = 1) })
            Tab(selected = selectedTab == 1, onClick = { onSelectTab(1) }, text = { Text(strings.clinicAndVaccines, maxLines = 1) })
            Tab(selected = selectedTab == 2, onClick = { onSelectTab(2) }, text = { Text(strings.growthMonitor, maxLines = 1) })
        }

        if (activeChild == null) {
            Box(modifier = Modifier.padding(16.dp)) {
                EmptyNoticeCard(title = strings.addChild, body = strings.noChildYet)
            }
            return
        }

        when (selectedTab) {
            0 -> MedicalRecordsTab(
                child = activeChild,
                language = language,
                assessments = assessments.filter { it.childId == activeChild.id },
                consultations = consultations.filter { it.childId == activeChild.id },
                vaccinations = vaccinations.filter { it.childId == activeChild.id },
                onUpdateMedical = onUpdateChildMedical
            )
            1 -> VaccinationsTab(
                child = activeChild,
                country = country,
                vaccinations = vaccinations.filter { it.childId == activeChild.id },
                onUpdateStatus = onUpdateVaccineStatus
            )
            else -> GrowthTab(
                child = activeChild,
                logs = growthLogs.filter { it.childId == activeChild.id },
                onAddLog = onAddGrowthLog
            )
        }
    }
}

@Composable
private fun MedicalRecordsTab(
    child: ChildProfile,
    language: AppLanguage,
    assessments: List<HealthAssessment>,
    consultations: List<ConsultationRecord>,
    vaccinations: List<VaccinationRecord>,
    onUpdateMedical: (String, String, String, String, String, String, String) -> Unit
) {
    val context = LocalContext.current
    var allergies by remember(child.id) { mutableStateOf(child.allergies) }
    var conditions by remember(child.id) { mutableStateOf(child.existingConditions) }
    var medications by remember(child.id) { mutableStateOf(child.medications) }
    var emergencyName by remember(child.id) { mutableStateOf(child.emergencyContactName) }
    var emergencyPhone by remember(child.id) { mutableStateOf(child.emergencyContactPhone) }
    var photoUri by remember(child.id) { mutableStateOf(child.photoUri) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            photoUri = uri.toString()
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SoftLightBlue),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(14.dp)) {
                    if (photoUri.isNotBlank()) {
                        AsyncImage(
                            model = photoUri,
                            contentDescription = child.fullName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                        )
                    } else {
                        Surface(color = PrimaryBlue, shape = CircleShape, modifier = Modifier.size(64.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.ChildCare, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(child.fullName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("DOB: ${child.dobText} • ${child.ageMonths} months • ${child.gender}", style = MaterialTheme.typography.bodySmall)
                        Text("Birth Weight: ${child.birthWeightKg} kg • Blood: ${child.bloodGroup.ifBlank { "Unknown" }}", style = MaterialTheme.typography.bodySmall)
                        Text("Location: ${child.location}", style = MaterialTheme.typography.labelSmall, color = PrimaryBlue)
                    }
                    OutlinedButton(
                        onClick = {
                            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                    ) {
                        Icon(Icons.Filled.AddAPhoto, contentDescription = "Pick photo", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        item {
            SectionHeader("Electronic Medical Record (EMR)", "Encrypted per-parent record • Authorized sharing")
        }

        item {
            OutlinedTextField(value = allergies, onValueChange = { allergies = it }, label = { Text("Allergies") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = conditions, onValueChange = { conditions = it }, label = { Text("Existing Conditions & Previous Illnesses") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = medications, onValueChange = { medications = it }, label = { Text("Current Medications") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = emergencyName, onValueChange = { emergencyName = it }, label = { Text("Emergency Contact") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = emergencyPhone, onValueChange = { emergencyPhone = it }, label = { Text("Phone") }, modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        onUpdateMedical(child.id, allergies, conditions, medications, emergencyName, emergencyPhone, photoUri)
                    },
                    modifier = Modifier.weight(1f).testTag("save_emr_button")
                ) {
                    Text("Save Medical Record")
                }
                OutlinedButton(
                    onClick = {
                        val export = buildString {
                            appendLine("TOTOCARE ELECTRONIC MEDICAL RECORD")
                            appendLine("Child: ${child.fullName} | DOB: ${child.dobText} | Age: ${child.ageMonths}m | Gender: ${child.gender}")
                            appendLine("Birth Weight: ${child.birthWeightKg} kg | Blood Group: ${child.bloodGroup}")
                            appendLine("Allergies: ${allergies.ifBlank { "None" }}")
                            appendLine("Conditions: ${conditions.ifBlank { "None" }}")
                            appendLine("Medications: ${medications.ifBlank { "None" }}")
                            appendLine("Emergency Contact: $emergencyName ($emergencyPhone)")
                            appendLine("Completed Vaccines: ${vaccinations.count { it.status == "completed" }}/${vaccinations.size}")
                            consultations.firstOrNull()?.let {
                                appendLine("Latest Consultation: ${it.doctorName} (${it.status}) - Rx: ${it.prescriptionText}")
                            }
                        }
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "TOTOCARE Medical Record: ${child.fullName}")
                            putExtra(Intent.EXTRA_TEXT, export)
                        }
                        context.startActivity(Intent.createChooser(intent, "Share Authorized Medical Record"))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export EMR")
                }
            }
        }

        if (consultations.any { it.prescriptionText.isNotBlank() || it.doctorNotes.isNotBlank() }) {
            item {
                SectionHeader("Doctor Prescriptions & Clinical Notes")
            }
            items(consultations.filter { it.prescriptionText.isNotBlank() || it.doctorNotes.isNotBlank() }) { c ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${c.doctorName} • ${c.specialty}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        if (c.doctorNotes.isNotBlank()) Text("Notes: ${c.doctorNotes}", style = MaterialTheme.typography.bodySmall)
                        if (c.prescriptionText.isNotBlank()) Text("Prescription: ${c.prescriptionText}", style = MaterialTheme.typography.bodySmall, color = PrimaryBlue)
                        if (c.referralSpecialty.isNotBlank()) Text("Specialist Referral: ${c.referralSpecialty}", style = MaterialTheme.typography.labelMedium, color = HealthcareTeal)
                    }
                }
            }
        }

        if (assessments.isNotEmpty()) {
            item {
                SectionHeader("AI Assessment & Cry History")
            }
            items(assessments.take(6), key = { it.id }) { a ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (a.kind == "cry") "Baby Cry AI" else "Symptom Triage", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            RiskLevelBadge(riskLevel = RiskLevel.fromCode(a.riskLevel), language = language)
                        }
                        Text(a.symptomsSummary, style = MaterialTheme.typography.bodySmall)
                        Text(a.nextSteps, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun VaccinationsTab(
    child: ChildProfile,
    country: CountryConfig,
    vaccinations: List<VaccinationRecord>,
    onUpdateStatus: (String, String, String, String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Surface(color = SoftLightBlue, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Filled.Vaccines, contentDescription = null, tint = PrimaryBlue)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(country.ministryName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(country.immunizationNote, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        if (vaccinations.isEmpty()) {
            item {
                EmptyNoticeCard("No Vaccines Seeded", "Register a child via the + button to generate the official EPI schedule.")
            }
        } else {
            items(vaccinations, key = { it.id }) { vac ->
                val statusColor = when (vac.status) {
                    "completed" -> RiskGreen
                    "missed" -> RiskRed
                    else -> RiskOrange
                }
                Card(
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(vac.vaccineName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("${vac.ageScheduleLabel} • ${vac.doseLabel} • ${vac.clinicName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Surface(
                                color = if (vac.status == "completed") RiskGreenContainer else statusColor.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = vac.status.uppercase(),
                                    color = statusColor,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = vac.status == "completed",
                                onClick = { onUpdateStatus(vac.id, "completed", "2026-11-24", vac.clinicName.ifBlank { "RCH Clinic" }) },
                                leadingIcon = { Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text("Given") }
                            )
                            FilterChip(
                                selected = vac.status == "upcoming",
                                onClick = { onUpdateStatus(vac.id, "upcoming", "", vac.clinicName) },
                                label = { Text("Upcoming") }
                            )
                            FilterChip(
                                selected = vac.status == "missed",
                                onClick = { onUpdateStatus(vac.id, "missed", "", vac.clinicName) },
                                label = { Text("Missed") }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GrowthTab(
    child: ChildProfile,
    logs: List<GrowthMeasurement>,
    onAddLog: (ChildProfile, Double, Double, Double, String, String) -> Unit
) {
    var weightText by remember { mutableStateOf("") }
    var heightText by remember { mutableStateOf("") }
    var headText by remember { mutableStateOf("") }
    var dateText by remember { mutableStateOf("2026-11-24") }
    var milestoneText by remember { mutableStateOf("") }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            GrowthProgressChart(logs = logs)
        }

        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Log Clinic Growth Measurement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = weightText, onValueChange = { weightText = it }, label = { Text("Weight (kg)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = heightText, onValueChange = { heightText = it }, label = { Text("Height (cm)") }, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = headText, onValueChange = { headText = it }, label = { Text("Head (cm)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = dateText, onValueChange = { dateText = it }, label = { Text("Date") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = milestoneText, onValueChange = { milestoneText = it }, label = { Text("Developmental Milestone / Nutrition Note") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            val w = weightText.toDoubleOrNull() ?: 9.5
                            val h = heightText.toDoubleOrNull() ?: 75.0
                            val hc = headText.toDoubleOrNull() ?: 45.0
                            onAddLog(child, w, h, hc, dateText, milestoneText)
                            weightText = ""
                            heightText = ""
                            headText = ""
                            milestoneText = ""
                        },
                        modifier = Modifier.fillMaxWidth().testTag("save_growth_button")
                    ) {
                        Text("Save Growth Entry")
                    }
                }
            }
        }

        items(logs.reversed(), key = { it.id }) { entry ->
            Card(
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("${entry.recordedDateText} • ${entry.weightKg} kg • ${entry.heightCm} cm • Head ${entry.headCircumferenceCm} cm", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    if (entry.milestoneNote.isNotBlank()) {
                        Text(entry.milestoneNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
