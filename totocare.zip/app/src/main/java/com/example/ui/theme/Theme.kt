package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val TotoLightColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = PureWhite,
    primaryContainer = SoftLightBlue,
    onPrimaryContainer = DarkNavy,
    secondary = HealthcareTeal,
    onSecondary = PureWhite,
    secondaryContainer = SoftTealTint,
    onSecondaryContainer = DarkNavy,
    tertiary = DarkNavy,
    onTertiary = PureWhite,
    background = OffWhiteCanvas,
    onBackground = DarkNavy,
    surface = PureWhite,
    onSurface = DarkNavy,
    surfaceVariant = SoftLightBlue,
    onSurfaceVariant = SlateMuted,
    outline = DividerBlue,
    error = RiskRed,
    onError = PureWhite,
    errorContainer = RiskRedContainer,
    onErrorContainer = RiskRed
)

private val TotoDarkColorScheme = darkColorScheme(
    primary = ColorTokens.DarkPrimary,
    onPrimary = DarkNavy,
    primaryContainer = DarkSurfaceVariant,
    onPrimaryContainer = SoftLightBlue,
    secondary = HealthcareTeal,
    onSecondary = DarkNavy,
    secondaryContainer = ColorTokens.DarkTealContainer,
    onSecondaryContainer = SoftTealTint,
    background = DarkBg,
    onBackground = PureWhite,
    surface = DarkSurface,
    onSurface = PureWhite,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = ColorTokens.DarkMutedText,
    outline = ColorTokens.DarkOutline,
    error = RiskRed,
    onError = PureWhite
)

private object ColorTokens {
    val DarkPrimary = androidx.compose.ui.graphics.Color(0xFF63B3F6)
    val DarkTealContainer = androidx.compose.ui.graphics.Color(0xFF0E4943)
    val DarkMutedText = androidx.compose.ui.graphics.Color(0xFFB3C7DA)
    val DarkOutline = androidx.compose.ui.graphics.Color(0xFF284664)
}

val TotoShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun TotoCareTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) TotoDarkColorScheme else TotoLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = TotoTypography,
        shapes = TotoShapes,
        content = content
    )
}
