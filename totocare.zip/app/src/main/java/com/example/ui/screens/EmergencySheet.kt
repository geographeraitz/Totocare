package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.CountryConfig
import com.example.data.ChildProfile
import com.example.data.RiskLevel
import com.example.data.TanzaniaHealthDirectories
import com.example.ui.components.RiskLevelBadge
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RiskGreen
import com.example.ui.theme.RiskOrange
import com.example.ui.theme.RiskRed
import com.example.ui.theme.RiskRedContainer
import com.example.ui.theme.RiskYellow

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EmergencyAssistanceSheet(
    child: ChildProfile?,
    country: CountryConfig,
    language: AppLanguage,
    gpsCoordinates: Pair<Double, Double>?,
    onDismiss: () -> Unit,
    onEscalateToDoctor: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedFlags by remember { mutableStateOf(setOf<String>()) }

    val redFlags = remember(language) {
        if (language == AppLanguage.KISWAHILI) {
            listOf(
                "Anapumua kwa shida au haraka",
                "Degedege / kutetemeka",
                "Amepoteza fahamu / haamki",
                "Hawezi kunyonya au kunywa",
                "Mtoto mchanga (< siku 28) ana homa",
                "Anatapika kila kitu",
                "Kutokwa na damu nyingi"
            )
        } else {
            listOf(
                "Difficulty or fast breathing",
                "Convulsions / seizures",
                "Unconscious / hard to wake",
                "Cannot drink or breastfeed",
                "Newborn (<28 days) with fever",
                "Vomiting everything",
                "Severe bleeding or injury"
            )
        }
    }

    val orangeFlags = remember(language) {
        if (language == AppLanguage.KISWAHILI) {
            listOf("Homa kali (>38.5°C)", "Kuhara mara nyingi", "Kulia kwa maumivu makali")
        } else {
            listOf("High fever (>38.5°C)", "Frequent watery diarrhea", "Inconsolable pain cry")
        }
    }

    val computedRisk = remember(selectedFlags, redFlags, orangeFlags) {
        when {
            selectedFlags.any { it in redFlags } -> RiskLevel.RED
            selectedFlags.any { it in orangeFlags } -> RiskLevel.ORANGE
            selectedFlags.isNotEmpty() -> RiskLevel.YELLOW
            else -> RiskLevel.RED // Emergency button defaults to immediate safety readiness
        }
    }

    val nearestFacility = remember(gpsCoordinates) {
        if (gpsCoordinates != null) {
            TanzaniaHealthDirectories.facilities
                .filter { it.hasEmergencyUnit }
                .minByOrNull {
                    TanzaniaHealthDirectories.distanceKm(
                        gpsCoordinates.first, gpsCoordinates.second, it.latitude, it.longitude
                    )
                } ?: TanzaniaHealthDirectories.facilities.first()
        } else {
            TanzaniaHealthDirectories.facilities.first()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Emergency,
                        contentDescription = null,
                        tint = RiskRed,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (language == AppLanguage.KISWAHILI) "Msaada wa Dharura" else "Child Emergency Assistance",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = RiskRed
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close")
                }
            }

            // Active Risk Classification Banner
            Surface(
                color = RiskRedContainer,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, RiskRed.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    RiskLevelBadge(riskLevel = computedRisk, language = language)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (language == AppLanguage.KISWAHILI) computedRisk.guidanceSw else computedRisk.guidanceEn,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // 4-Tier Risk Classification Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "RED" to RiskRed,
                    "ORANGE" to RiskOrange,
                    "YELLOW" to RiskYellow,
                    "GREEN" to RiskGreen
                ).forEach { (label, color) ->
                    Surface(
                        color = color.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = label,
                            color = color,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
                        )
                    }
                }
            }

            Text(
                text = if (language == AppLanguage.KISWAHILI)
                    "Chagua dalili zilizopo sasa (GREEN haiwezi kufunika dalili hatari):"
                else
                    "Tap any observed danger signs for tailored instructions:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                (redFlags + orangeFlags).forEach { flag ->
                    val selected = flag in selectedFlags
                    FilterChip(
                        selected = selected,
                        onClick = {
                            selectedFlags = if (selected) selectedFlags - flag else selectedFlags + flag
                        },
                        label = { Text(flag, style = MaterialTheme.typography.bodySmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RiskRed,
                            selectedLabelColor = MaterialTheme.colorScheme.onError
                        )
                    )
                }
            }

            // Immediate First-Aid Instructions
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (language == AppLanguage.KISWAHILI) "Hatua za Haraka za Usalama" else "Immediate Stabilization Steps",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    val steps = if (language == AppLanguage.KISWAHILI) {
                        listOf(
                            "1. Kaa mtulivu; usimpe mtoto chakula au maji kama amepoteza fahamu au ana degedege.",
                            "2. Kwa degedege: mlaze ubavu sehemu salama, usimzuie kwa nguvu au kuweka kitu mdomoni.",
                            "3. Kwa homa kali: vaa nguo nyepesi, futa mwili kwa kitambaa chenye maji ya uvuguvugu.",
                            "4. Nenda kituo cha dharura kilicho karibu mara moja."
                        )
                    } else {
                        listOf(
                            "1. Stay calm; do NOT give food or fluids if the child is drowsy, unconscious, or convulsing.",
                            "2. For convulsions: place the child gently on their side in recovery position; never put anything in their mouth.",
                            "3. For breathing trouble: keep airway clear, keep child upright/comfortable, and head to emergency care immediately.",
                            "4. Bring your child's clinic card or share their TOTOCARE medical profile on arrival."
                        )
                    }
                    steps.forEach { step ->
                        Text(text = step, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // Primary Emergency Call Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${country.emergencyNumber}"))
                        context.startActivity(dial)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RiskRed),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("call_emergency_button")
                ) {
                    Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call ${country.emergencyNumber}", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${country.ambulanceNumber}"))
                        context.startActivity(dial)
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Icon(Icons.Filled.LocalHospital, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Amb. ${country.ambulanceNumber}")
                }
            }

            // Nearest Emergency Facility Card
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (language == AppLanguage.KISWAHILI) "Hospitali ya Dharura Iliyo Karibu" else "Nearest Pediatric Emergency Facility",
                        style = MaterialTheme.typography.labelLarge,
                        color = PrimaryBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = nearestFacility.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(text = "${nearestFacility.address} • ${nearestFacility.hours}", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${nearestFacility.phone}"))
                                context.startActivity(dial)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call Facility")
                        }
                        Button(
                            onClick = {
                                val geoUri = Uri.parse(
                                    "geo:${nearestFacility.latitude},${nearestFacility.longitude}?q=${Uri.encode(nearestFacility.name)}"
                                )
                                context.startActivity(Intent(Intent.ACTION_VIEW, geoUri))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Directions, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Directions")
                        }
                    }
                }
            }

            // Share Child Profile + Location + Emergency Contact
            val shareSummary = buildString {
                appendLine("TOTOCARE EMERGENCY ALERT")
                appendLine("Risk Classification: ${computedRisk.code}")
                if (child != null) {
                    appendLine("Child: ${child.fullName} (${child.ageMonths} months, ${child.gender})")
                    if (child.bloodGroup.isNotBlank()) appendLine("Blood Group: ${child.bloodGroup}")
                    if (child.allergies.isNotBlank()) appendLine("Allergies: ${child.allergies}")
                    if (child.existingConditions.isNotBlank()) appendLine("Conditions: ${child.existingConditions}")
                    if (child.medications.isNotBlank()) appendLine("Medications: ${child.medications}")
                    if (child.emergencyContactPhone.isNotBlank()) {
                        appendLine("Emergency Contact: ${child.emergencyContactName} (${child.emergencyContactPhone})")
                    }
                }
                if (selectedFlags.isNotEmpty()) {
                    appendLine("Observed Danger Signs: ${selectedFlags.joinToString(", ")}")
                }
                if (gpsCoordinates != null) {
                    appendLine("GPS Location: https://maps.google.com/?q=${gpsCoordinates.first},${gpsCoordinates.second}")
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "TOTOCARE Emergency Child Profile")
                            putExtra(Intent.EXTRA_TEXT, shareSummary)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share Emergency Profile"))
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share Profile & GPS")
                }

                Button(
                    onClick = {
                        onDismiss()
                        onEscalateToDoctor()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Connect Pediatrician")
                }
            }

            if (child?.emergencyContactPhone?.isNotBlank() == true) {
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${child.emergencyContactPhone}")))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Notify Emergency Contact: ${child.emergencyContactName}")
                }
            }
        }
    }
}
