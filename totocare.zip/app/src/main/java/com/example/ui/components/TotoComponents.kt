package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.AppLanguage
import com.example.data.ChildProfile
import com.example.data.GrowthMeasurement
import com.example.data.RiskLevel
import com.example.ui.theme.HealthcareTeal
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RiskGreen
import com.example.ui.theme.RiskGreenContainer
import com.example.ui.theme.RiskOrange
import com.example.ui.theme.RiskOrangeContainer
import com.example.ui.theme.RiskRed
import com.example.ui.theme.RiskRedContainer
import com.example.ui.theme.RiskYellow
import com.example.ui.theme.RiskYellowContainer

@Composable
fun riskColors(riskLevel: RiskLevel): Pair<Color, Color> = when (riskLevel) {
    RiskLevel.RED -> RiskRed to RiskRedContainer
    RiskLevel.ORANGE -> RiskOrange to RiskOrangeContainer
    RiskLevel.YELLOW -> RiskYellow to RiskYellowContainer
    RiskLevel.GREEN -> RiskGreen to RiskGreenContainer
}

@Composable
fun RiskLevelBadge(
    riskLevel: RiskLevel,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val (fg, bg) = riskColors(riskLevel)
    val label = if (language == AppLanguage.KISWAHILI) riskLevel.labelSw else riskLevel.labelEn
    Surface(
        color = bg,
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.4f)),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = fg,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun MedicalDisclaimerBanner(
    text: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.HealthAndSafety,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
fun ChildSelectorBar(
    children: List<ChildProfile>,
    selectedChildId: String?,
    onSelectChild: (String) -> Unit,
    onAddChildClick: () -> Unit,
    addLabel: String,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        children.forEach { child ->
            val selected = child.id == selectedChildId
            FilterChip(
                selected = selected,
                onClick = { onSelectChild(child.id) },
                label = {
                    Text(
                        text = "${child.fullName} (${child.ageMonths}m)",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    if (child.photoUri.isNotBlank()) {
                        AsyncImage(
                            model = child.photoUri,
                            contentDescription = child.fullName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.ChildCare,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
        Surface(
            color = MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(50),
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .clickable(onClick = onAddChildClick)
                .testTag("add_child_chip")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = addLabel,
                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = addLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold
        )
        if (!subtitle.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun GrowthProgressChart(
    logs: List<GrowthMeasurement>,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Weight & Height Trajectory",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    LegendDot(color = PrimaryBlue, label = "Weight (kg)")
                    LegendDot(color = HealthcareTeal, label = "Height (cm)")
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            if (logs.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "Log your child's weight and height to visualize growth progress.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                val points = logs.takeLast(8)
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                ) {
                    val pad = 18.dp.toPx()
                    val chartW = (size.width - pad * 2).coerceAtLeast(1f)
                    val chartH = (size.height - pad * 2).coerceAtLeast(1f)

                    // Grid lines
                    for (i in 0..3) {
                        val y = pad + (chartH / 3f) * i
                        drawLine(
                            color = Color(0xFFD6E6F2),
                            start = Offset(pad, y),
                            end = Offset(size.width - pad, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    val minW = (points.minOf { it.weightKg } - 1.0).coerceAtLeast(0.0)
                    val maxW = (points.maxOf { it.weightKg } + 1.0).coerceAtLeast(minW + 2.0)
                    val minH = (points.minOf { it.heightCm } - 3.0).coerceAtLeast(20.0)
                    val maxH = (points.maxOf { it.heightCm } + 3.0).coerceAtLeast(minH + 5.0)

                    val weightPath = Path()
                    val heightPath = Path()

                    points.forEachIndexed { idx, entry ->
                        val x = if (points.size == 1) pad + chartW / 2f else pad + (chartW * idx / (points.size - 1).toFloat())
                        val wy = pad + chartH * (1f - ((entry.weightKg - minW) / (maxW - minW)).toFloat())
                        val hy = pad + chartH * (1f - ((entry.heightCm - minH) / (maxH - minH)).toFloat())

                        if (idx == 0) {
                            weightPath.moveTo(x, wy)
                            heightPath.moveTo(x, hy)
                        } else {
                            weightPath.lineTo(x, wy)
                            heightPath.lineTo(x, hy)
                        }
                    }

                    drawPath(
                        path = heightPath,
                        color = HealthcareTeal,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                    drawPath(
                        path = weightPath,
                        color = PrimaryBlue,
                        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                    )

                    points.forEachIndexed { idx, entry ->
                        val x = if (points.size == 1) pad + chartW / 2f else pad + (chartW * idx / (points.size - 1).toFloat())
                        val wy = pad + chartH * (1f - ((entry.weightKg - minW) / (maxW - minW)).toFloat())
                        val hy = pad + chartH * (1f - ((entry.heightCm - minH) / (maxH - minH)).toFloat())
                        drawCircle(color = PrimaryBlue, radius = 5.dp.toPx(), center = Offset(x, wy))
                        drawCircle(color = HealthcareTeal, radius = 4.5.dp.toPx(), center = Offset(x, hy))
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun CryWaveformVisualizer(
    bars: List<Float>,
    activeColor: Color = PrimaryBlue,
    modifier: Modifier = Modifier
) {
    val displayBars = if (bars.isEmpty()) List(24) { 0.14f } else bars
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        displayBars.takeLast(24).forEach { level ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height((44f * level.coerceIn(0.12f, 1f)).dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(activeColor)
            )
        }
    }
}

@Composable
fun EmptyNoticeCard(
    title: String,
    body: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
