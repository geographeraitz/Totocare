package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.core.AppLanguage
import com.example.core.AudioCryRecorder
import com.example.core.CryAudioRecording
import com.example.core.TotoStrings
import com.example.data.AgeGroup
import com.example.data.ChildProfile
import com.example.data.CryAnalysisResult
import com.example.data.RiskLevel
import com.example.data.SymptomAssessmentResult
import com.example.ui.AiTaskState
import com.example.ui.AssistantChatItem
import com.example.ui.components.CryWaveformVisualizer
import com.example.ui.components.MedicalDisclaimerBanner
import com.example.ui.components.RiskLevelBadge
import com.example.ui.components.SectionHeader
import com.example.ui.theme.HealthcareTeal
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RiskRed
import com.example.ui.theme.SoftLightBlue
import com.example.ui.theme.SoftTealTint
import kotlinx.coroutines.launch

@Composable
fun AssessHubScreen(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    activeChild: ChildProfile?,
    language: AppLanguage,
    strings: TotoStrings,
    symptomState: AiTaskState<SymptomAssessmentResult>,
    cryState: AiTaskState<CryAnalysisResult>,
    assistantMessages: List<AssistantChatItem>,
    assistantBusy: Boolean,
    onRunSymptomAssessment: (AgeGroup, String, List<String>, Map<String, String>, Bitmap?) -> Unit,
    onRunCryAnalysis: (CryAudioRecording, Map<String, String>, String) -> Unit,
    onSendAssistantMessage: (String) -> Unit,
    onOpenEmergency: () -> Unit,
    onEscalateToDoctor: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { onSelectTab(0) },
                text = { Text(strings.checkSymptoms, maxLines = 1) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { onSelectTab(1) },
                text = { Text(strings.recordBabyCry, maxLines = 1) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { onSelectTab(2) },
                text = { Text(strings.aiAssistant, maxLines = 1) }
            )
        }

        when (selectedTab) {
            0 -> SymptomCheckerTab(
                activeChild = activeChild,
                language = language,
                strings = strings,
                symptomState = symptomState,
                onRunAssessment = onRunSymptomAssessment,
                onOpenEmergency = onOpenEmergency,
                onEscalateToDoctor = onEscalateToDoctor
            )
            1 -> BabyCryAnalysisTab(
                activeChild = activeChild,
                language = language,
                strings = strings,
                cryState = cryState,
                onRunCryAnalysis = onRunCryAnalysis,
                onOpenEmergency = onOpenEmergency,
                onSendToDoctor = onEscalateToDoctor
            )
            else -> AiAssistantTab(
                activeChild = activeChild,
                language = language,
                strings = strings,
                messages = assistantMessages,
                isBusy = assistantBusy,
                onSend = onSendAssistantMessage
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SymptomCheckerTab(
    activeChild: ChildProfile?,
    language: AppLanguage,
    strings: TotoStrings,
    symptomState: AiTaskState<SymptomAssessmentResult>,
    onRunAssessment: (AgeGroup, String, List<String>, Map<String, String>, Bitmap?) -> Unit,
    onOpenEmergency: () -> Unit,
    onEscalateToDoctor: (String) -> Unit
) {
    val context = LocalContext.current
    var ageGroup by remember(activeChild?.id) {
        mutableStateOf(AgeGroup.fromCode(activeChild?.ageGroup))
    }
    var symptomsText by remember { mutableStateOf("") }
    var selectedSymptoms by remember { mutableStateOf(setOf<String>()) }
    var durationAnswer by remember { mutableStateOf("Less than 24 hours") }
    var drinkingAnswer by remember { mutableStateOf("Yes, drinking/feeding normally") }
    var breathingAnswer by remember { mutableStateOf("No breathing difficulty") }
    var attachedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                symptomsText = if (symptomsText.isBlank()) spoken else "$symptomsText. $spoken"
            }
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val decoded = BitmapFactory.decodeStream(stream)
                    if (decoded != null) {
                        val maxDim = 900
                        val scale = minOf(maxDim.toFloat() / decoded.width, maxDim.toFloat() / decoded.height, 1f)
                        attachedBitmap = if (scale < 1f) {
                            Bitmap.createScaledBitmap(
                                decoded,
                                (decoded.width * scale).toInt(),
                                (decoded.height * scale).toInt(),
                                true
                            )
                        } else decoded
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    val symptomLibrary = remember(language) {
        if (language == AppLanguage.KISWAHILI) {
            listOf("Homa", "Kikohozi", "Kuhara", "Kutapika", "Upele wa ngozi", "Kukataa kunyonya", "Maumivu ya sikio", "Uchovu mkali")
        } else {
            listOf("Fever", "Cough / Cold", "Diarrhea", "Vomiting", "Skin Rash", "Poor Feeding", "Ear Pain", "Unusual Lethargy")
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            SectionHeader(
                title = if (language == AppLanguage.KISWAHILI) "Tathmini ya Dalili kwa AI" else "AI Child Symptom Triage",
                subtitle = activeChild?.let { "Assessing: ${it.fullName} (${it.ageMonths} months)" }
                    ?: "Select child age bracket (0 months – 13 years)"
            )
        }

        item {
            MedicalDisclaimerBanner(text = strings.medicalDisclaimer)
        }

        // Age group selector (5 pediatric brackets)
        item {
            Text(
                text = if (language == AppLanguage.KISWAHILI) "Kundi la Umri:" else "Age Bracket (Clinical Risk Stratification):",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AgeGroup.entries.forEach { group ->
                    FilterChip(
                        selected = ageGroup == group,
                        onClick = { ageGroup = group },
                        label = {
                            val name = if (language == AppLanguage.KISWAHILI) group.labelSw else group.labelEn
                            Text("$name (${group.rangeLabel})", style = MaterialTheme.typography.labelMedium)
                        }
                    )
                }
            }
        }

        // Symptom library chips
        item {
            Text(
                text = if (language == AppLanguage.KISWAHILI) "Chagua Dalili Kutoka Maktaba:" else "Medical Symptom Library:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                symptomLibrary.forEach { sym ->
                    val selected = sym in selectedSymptoms
                    FilterChip(
                        selected = selected,
                        onClick = {
                            selectedSymptoms = if (selected) selectedSymptoms - sym else selectedSymptoms + sym
                        },
                        label = { Text(sym) }
                    )
                }
            }
        }

        // Description + Voice Dictation + Photo Picker
        item {
            OutlinedTextField(
                value = symptomsText,
                onValueChange = { symptomsText = it },
                label = {
                    Text(
                        if (language == AppLanguage.KISWAHILI) "Eleza dalili za mtoto (andika au ongea)"
                        else "Describe symptoms, temperature, or behavior"
                    )
                },
                minLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("symptom_description_input")
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (language == AppLanguage.KISWAHILI) "sw-TZ" else "en-US")
                        }
                        try {
                            speechLauncher.launch(intent)
                        } catch (_: Exception) {
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Speak")
                }
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (attachedBitmap != null) "Photo Added" else "Attach Photo")
                }
            }
            if (attachedBitmap != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Image(
                    bitmap = attachedBitmap!!.asImageBitmap(),
                    contentDescription = "Attached symptom photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(14.dp))
                )
            }
        }

        // Guided safety questions
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (language == AppLanguage.KISWAHILI) "Maswali Muhimu ya Usalama" else "Guided Medical Safety Questions",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Duration:", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Less than 24 hours", "1–3 days", "Over 3 days").forEach { opt ->
                            FilterChip(selected = durationAnswer == opt, onClick = { durationAnswer = opt }, label = { Text(opt) })
                        }
                    }
                    Text("Drinking / Breastfeeding:", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Yes, drinking/feeding normally", "Reduced intake", "Unable to drink / vomiting all").forEach { opt ->
                            FilterChip(selected = drinkingAnswer == opt, onClick = { drinkingAnswer = opt }, label = { Text(opt) })
                        }
                    }
                    Text("Breathing & Alertness:", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("No breathing difficulty", "Fast breathing / chest indrawing", "Very sleepy or convulsions").forEach { opt ->
                            FilterChip(selected = breathingAnswer == opt, onClick = { breathingAnswer = opt }, label = { Text(opt) })
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    onRunAssessment(
                        ageGroup,
                        symptomsText,
                        selectedSymptoms.toList(),
                        mapOf(
                            "Duration" to durationAnswer,
                            "Feeding/Drinking" to drinkingAnswer,
                            "Breathing/Alertness" to breathingAnswer
                        ),
                        attachedBitmap
                    )
                },
                enabled = symptomState !is AiTaskState.Loading && (symptomsText.isNotBlank() || selectedSymptoms.isNotEmpty() || attachedBitmap != null),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("run_symptom_ai_button")
            ) {
                if (symptomState is AiTaskState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Evaluating with Gemini Pediatric AI...")
                } else {
                    Text(
                        text = if (language == AppLanguage.KISWAHILI) "Fanya Tathmini ya AI" else "Evaluate Symptoms with AI",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Result rendering
        when (symptomState) {
            is AiTaskState.Error -> {
                item {
                    Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Text(symptomState.message, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(14.dp))
                    }
                }
            }
            is AiTaskState.Success -> {
                val res = symptomState.data
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            RiskLevelBadge(riskLevel = res.riskLevel, language = language)
                            if (res.riskLevel == RiskLevel.RED || res.riskLevel == RiskLevel.ORANGE) {
                                Button(
                                    onClick = onOpenEmergency,
                                    colors = ButtonDefaults.buttonColors(containerColor = RiskRed),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Filled.Emergency, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open Emergency Assistance Now")
                                }
                            }
                            ResultBlock("Possible Explanations (Non-Diagnostic)", res.possibleExplanations)
                            ResultBlock("Recommended Next Steps", res.nextSteps)
                            ResultBlock("When to Visit Hospital Immediately", res.whenToVisitHospital)
                            ResultBlock("Health Education", res.healthEducation)
                            ResultBlock("Pediatrician Consultation", res.pediatricianSuggestion)
                            Surface(color = SoftLightBlue, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(res.clinicalDisclaimer, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(10.dp))
                            }
                            OutlinedButton(
                                onClick = {
                                    val summary = "AI Risk: ${res.riskLevel.code}. Symptoms: $symptomsText ${selectedSymptoms.joinToString(", ")}"
                                    onEscalateToDoctor(summary)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.VideoCall, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Book Pediatrician Review")
                            }
                        }
                    }
                }
            }
            else -> {}
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BabyCryAnalysisTab(
    activeChild: ChildProfile?,
    language: AppLanguage,
    strings: TotoStrings,
    cryState: AiTaskState<CryAnalysisResult>,
    onRunCryAnalysis: (CryAudioRecording, Map<String, String>, String) -> Unit,
    onOpenEmergency: () -> Unit,
    onSendToDoctor: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isRecording by remember { mutableStateOf(false) }
    val liveBars = remember { mutableStateListOf<Float>() }
    var lastRecording by remember { mutableStateOf<CryAudioRecording?>(null) }
    var recordError by remember { mutableStateOf<String?>(null) }
    var parentNotes by remember { mutableStateOf("") }
    var selectedChecks by remember { mutableStateOf(setOf<String>()) }

    fun startRealMicRecording() {
        isRecording = true
        recordError = null
        liveBars.clear()
        scope.launch {
            val result = AudioCryRecorder.recordSample(durationMillis = 4500L) { amp ->
                liveBars.add(amp)
            }
            isRecording = false
            result.fold(
                onSuccess = { rec -> lastRecording = rec },
                onFailure = { err -> recordError = err.localizedMessage ?: "Audio capture failed." }
            )
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startRealMicRecording()
        } else {
            recordError = "Microphone permission is required to record baby cry audio."
        }
    }

    val warningChecks = listOf(
        "Has fever or feels very hot",
        "Refusing breastmilk or fluids",
        "Fast or labored breathing",
        "High-pitched continuous cry >2 hours"
    )

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SoftLightBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Image(
                        painter = painterResource(id = R.drawable.img_cry_analysis),
                        contentDescription = "Baby cry acoustic analysis",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(145.dp)
                    )
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (language == AppLanguage.KISWAHILI) "Uchambuzi wa Kilio & Sauti ya Mtoto" else "AI Baby Cry & Voice Pattern Analysis",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Investigates crying intensity, duration, pitch, and vocal patterns for possible hunger, sleepiness, discomfort, attention need, pain, or distress — while clearly communicating uncertainty.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            CryWaveformVisualizer(
                bars = lastRecording?.waveformBars ?: liveBars.toList(),
                activeColor = if (isRecording) RiskRed else HealthcareTeal
            )
            if (lastRecording != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Captured ${"%.1f".format(lastRecording!!.durationSeconds)}s WAV • Est. Pitch: ~${lastRecording!!.estimatedPitchHz} Hz • Energy: ${"%.1f".format(lastRecording!!.rmsEnergyDb)} dBFS",
                    style = MaterialTheme.typography.labelMedium,
                    color = PrimaryBlue
                )
            }
            if (!recordError.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = recordError!!, color = RiskRed, style = MaterialTheme.typography.bodySmall)
            }
        }

        item {
            Button(
                onClick = {
                    val hasPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (hasPerm) {
                        startRealMicRecording()
                    } else {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                enabled = !isRecording,
                colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) RiskRed else PrimaryBlue),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("record_cry_button")
            ) {
                Icon(Icons.Filled.GraphicEq, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isRecording) "Recording 4.5s Audio Sample..." else if (lastRecording == null) "Record Baby Cry (4.5s)" else "Record New Cry Sample",
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        item {
            Text(
                text = "Additional Warning Sign Check (Required for Safe Triage):",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                warningChecks.forEach { chk ->
                    val sel = chk in selectedChecks
                    FilterChip(
                        selected = sel,
                        onClick = { selectedChecks = if (sel) selectedChecks - chk else selectedChecks + chk },
                        label = { Text(chk, style = MaterialTheme.typography.bodySmall) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = parentNotes,
                onValueChange = { parentNotes = it },
                label = { Text("Context (e.g. last fed 3 hours ago, pulling ear)") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Button(
                onClick = {
                    val rec = lastRecording
                    if (rec != null) {
                        val answers = warningChecks.associateWith { if (it in selectedChecks) "Yes" else "No" }
                        onRunCryAnalysis(rec, answers, parentNotes)
                    }
                },
                enabled = lastRecording != null && cryState !is AiTaskState.Loading,
                colors = ButtonDefaults.buttonColors(containerColor = HealthcareTeal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("analyze_cry_button")
            ) {
                if (cryState is AiTaskState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onSecondary, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Analyzing Acoustic Cry Patterns...")
                } else {
                    Text("Investigate Cry Patterns with AI", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        when (cryState) {
            is AiTaskState.Error -> {
                item {
                    Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Text(cryState.message, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(14.dp))
                    }
                }
            }
            is AiTaskState.Success -> {
                val res = cryState.data
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            RiskLevelBadge(riskLevel = res.riskLevel, language = language)
                            if (res.primaryPatterns.isNotEmpty()) {
                                ResultBlock("Possible Pattern Associations", res.primaryPatterns.joinToString(" • "))
                            }
                            ResultBlock("Acoustic Observations", res.acousticSummary)
                            Surface(color = SoftLightBlue, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("What This Analysis Can & Cannot Infer", style = MaterialTheme.typography.labelLarge, color = PrimaryBlue)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(res.uncertaintyNotice, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            ResultBlock("Emergency Warning Check", res.emergencyWarningCheck)
                            ResultBlock("Recommended Next Steps", res.recommendedNextSteps)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                if (res.riskLevel == RiskLevel.RED || res.riskLevel == RiskLevel.ORANGE) {
                                    Button(
                                        onClick = onOpenEmergency,
                                        colors = ButtonDefaults.buttonColors(containerColor = RiskRed),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Emergency Help")
                                    }
                                }
                                OutlinedButton(
                                    onClick = {
                                        onSendToDoctor(
                                            "Baby Cry AI Report (${res.riskLevel.code}): ${res.primaryPatterns.joinToString(", ")}. ${res.acousticSummary}"
                                        )
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Send Recording Report to Doctor")
                                }
                            }
                        }
                    }
                }
            }
            else -> {}
        }

        item {
            MedicalDisclaimerBanner(text = strings.medicalDisclaimer)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AiAssistantTab(
    activeChild: ChildProfile?,
    language: AppLanguage,
    strings: TotoStrings,
    messages: List<AssistantChatItem>,
    isBusy: Boolean,
    onSend: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    val starterPrompts = if (language == AppLanguage.KISWAHILI) {
        listOf(
            "Eleza ratiba ya chanjo ya miezi 9 Tanzania",
            "Nisaidie kuandaa maswali kwa daktari wa watoto",
            "Jinsi ya kuandaa maji ya ORS nyumbani kwa usalama",
            "Lishe bora kwa mtoto wa miezi 6 hadi 12"
        )
    } else {
        listOf(
            "Explain the Tanzania EPI vaccination schedule",
            "Help me prepare questions for our pediatrician",
            "How do I recognize newborn danger signs?",
            "Child nutrition tips for 6–24 months"
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            item {
                MedicalDisclaimerBanner(text = strings.medicalDisclaimer)
            }
            if (messages.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = SoftTealTint),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Psychology, contentDescription = null, tint = HealthcareTeal)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (language == AppLanguage.KISWAHILI) "Msaidizi wa Afya ya Mtoto (Kiswahili & English)" else "TOTOCARE AI Healthcare Assistant",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = activeChild?.let { "Context loaded for ${it.fullName} (${it.ageMonths}m)." }
                                    ?: "Ask any child health, vaccine, nutrition, or clinic record question in English or Kiswahili.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                starterPrompts.forEach { q ->
                                    FilterChip(
                                        selected = false,
                                        onClick = { onSend(q) },
                                        label = { Text(q, style = MaterialTheme.typography.bodySmall) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            items(messages, key = { it.id }) { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (item.fromUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = if (item.fromUser) PrimaryBlue else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(16.dp),
                        border = if (item.fromUser) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = item.text.ifBlank { "..." },
                                color = if (item.fromUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }

        Surface(
            tonalElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = {
                        Text(if (language == AppLanguage.KISWAHILI) "Uliza swali kwa Kiswahili au Kiingereza..." else "Ask in English or Kiswahili...")
                    },
                    maxLines = 3,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("assistant_chat_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        val q = input
                        input = ""
                        onSend(q)
                    },
                    enabled = input.isNotBlank() && !isBusy,
                    modifier = Modifier.testTag("assistant_send_button")
                ) {
                    if (isBusy) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = PrimaryBlue)
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultBlock(title: String, body: String) {
    Column {
        Text(text = title, style = MaterialTheme.typography.labelLarge, color = PrimaryBlue, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = body, style = MaterialTheme.typography.bodyMedium)
    }
}
