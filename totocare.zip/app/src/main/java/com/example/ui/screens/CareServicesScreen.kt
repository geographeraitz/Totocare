package com.example.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.core.AppLanguage
import com.example.core.CountryConfig
import com.example.core.TotoStrings
import com.example.data.ChildProfile
import com.example.data.ConsultationMessage
import com.example.data.ConsultationRecord
import com.example.data.OfficialHealthBulletin
import com.example.data.PediatricSpecialist
import com.example.data.PharmacyListing
import com.example.data.PharmacyOrder
import com.example.data.TanzaniaHealthDirectories
import com.example.ui.components.EmptyNoticeCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.HealthcareTeal
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RiskGreen
import com.example.ui.theme.RiskOrange
import com.example.ui.theme.SoftLightBlue
import com.example.ui.theme.SoftTealTint
import com.google.android.gms.location.LocationServices

@Composable
fun CareServicesScreen(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    parentName: String,
    country: CountryConfig,
    language: AppLanguage,
    strings: TotoStrings,
    activeChild: ChildProfile?,
    gpsCoordinates: Pair<Double, Double>?,
    onGpsUpdated: (Double, Double) -> Unit,
    consultations: List<ConsultationRecord>,
    activeMessages: List<ConsultationMessage>,
    pharmacyOrders: List<PharmacyOrder>,
    bulletins: List<OfficialHealthBulletin>,
    prefillConsultNotes: String,
    onBookConsultation: (ChildProfile, PediatricSpecialist, String, String, String, String) -> Unit,
    onOpenConsultationChat: (String) -> Unit,
    onSendConsultationMessage: (String, String) -> Unit,
    onPlacePharmacyOrder: (String, PharmacyListing, Long, String, String, String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { onSelectTab(0) }, text = { Text("Hospitals", maxLines = 1) })
            Tab(selected = selectedTab == 1, onClick = { onSelectTab(1) }, text = { Text("Doctors", maxLines = 1) })
            Tab(selected = selectedTab == 2, onClick = { onSelectTab(2) }, text = { Text("Pharmacy", maxLines = 1) })
            Tab(selected = selectedTab == 3, onClick = { onSelectTab(3) }, text = { Text("Education", maxLines = 1) })
        }

        when (selectedTab) {
            0 -> NearbyHospitalsTab(gpsCoordinates = gpsCoordinates, onGpsUpdated = onGpsUpdated)
            1 -> TelemedicineTab(
                parentName = parentName,
                country = country,
                activeChild = activeChild,
                consultations = consultations,
                activeMessages = activeMessages,
                prefillNotes = prefillConsultNotes,
                onBook = onBookConsultation,
                onOpenChat = onOpenConsultationChat,
                onSendMessage = onSendConsultationMessage
            )
            2 -> PharmacyMarketplaceTab(
                country = country,
                activeChild = activeChild,
                orders = pharmacyOrders,
                onPlaceOrder = onPlacePharmacyOrder
            )
            else -> EducationOfficialTab(
                language = language,
                country = country,
                bulletins = bulletins
            )
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
private fun NearbyHospitalsTab(
    gpsCoordinates: Pair<Double, Double>?,
    onGpsUpdated: (Double, Double) -> Unit
) {
    val context = LocalContext.current
    var regionFilter by remember { mutableStateOf("All") }
    var erOnly by remember { mutableStateOf(false) }

    val locationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            try {
                LocationServices.getFusedLocationProviderClient(context).lastLocation
                    .addOnSuccessListener { loc ->
                        if (loc != null) onGpsUpdated(loc.latitude, loc.longitude)
                    }
            } catch (_: Exception) {
            }
        }
    }

    val regions = listOf("All", "Dar es Salaam", "Mwanza", "Arusha", "Dodoma", "Moshi / Kilimanjaro", "Zanzibar")
    val facilities = remember(regionFilter, erOnly, gpsCoordinates) {
        TanzaniaHealthDirectories.facilities
            .filter { (regionFilter == "All" || it.cityRegion == regionFilter) && (!erOnly || it.hasEmergencyUnit) }
            .sortedBy { fac ->
                if (gpsCoordinates != null) {
                    TanzaniaHealthDirectories.distanceKm(gpsCoordinates.first, gpsCoordinates.second, fac.latitude, fac.longitude)
                } else 0.0
            }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader("Nearby Pediatric Hospitals & Clinics", "GPS distance & direct emergency calling")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (granted) {
                            LocationServices.getFusedLocationProviderClient(context).lastLocation
                                .addOnSuccessListener { loc ->
                                    if (loc != null) onGpsUpdated(loc.latitude, loc.longitude)
                                }
                        } else {
                            locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                        }
                    }
                ) {
                    Icon(Icons.Filled.MyLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (gpsCoordinates == null) "Use My GPS Location" else "GPS Active")
                }
                FilterChip(selected = erOnly, onClick = { erOnly = !erOnly }, label = { Text("24/7 Emergency") })
            }
        }

        item {
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                regions.forEach { reg ->
                    FilterChip(selected = regionFilter == reg, onClick = { regionFilter = reg }, label = { Text(reg) })
                }
            }
        }

        items(facilities, key = { it.id }) { fac ->
            val distText = gpsCoordinates?.let { (lat, lon) ->
                val km = TanzaniaHealthDirectories.distanceKm(lat, lon, fac.latitude, fac.longitude)
                "${"%.1f".format(km)} km away"
            } ?: fac.cityRegion

            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LocalHospital, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(fac.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }
                    Text("${fac.facilityType} • $distText", style = MaterialTheme.typography.labelLarge, color = HealthcareTeal)
                    Text("${fac.address} • ${fac.hours}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Services: ${fac.services.joinToString(" • ")}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                        OutlinedButton(
                            onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${fac.phone}"))) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call")
                        }
                        Button(
                            onClick = {
                                val uri = Uri.parse("geo:${fac.latitude},${fac.longitude}?q=${Uri.encode(fac.name)}")
                                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Directions, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Directions")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemedicineTab(
    parentName: String,
    country: CountryConfig,
    activeChild: ChildProfile?,
    consultations: List<ConsultationRecord>,
    activeMessages: List<ConsultationMessage>,
    prefillNotes: String,
    onBook: (ChildProfile, PediatricSpecialist, String, String, String, String) -> Unit,
    onOpenChat: (String) -> Unit,
    onSendMessage: (String, String) -> Unit
) {
    var bookingDoctor by remember { mutableStateOf<PediatricSpecialist?>(null) }
    var activeChatConsult by remember { mutableStateOf<ConsultationRecord?>(null) }
    var specialtyFilter by remember { mutableStateOf("All") }

    val specialties = listOf("All", "General Pediatrician", "Neonatal Specialist", "Pediatric Cardiologist", "Pediatric Neurologist", "Pediatric Dermatologist", "Pediatric Surgeon")
    val doctors = TanzaniaHealthDirectories.specialists.filter {
        specialtyFilter == "All" || it.specialty.contains(specialtyFilter.removePrefix("Pediatric "), ignoreCase = true)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Image(
                painter = painterResource(id = R.drawable.img_clinic_care),
                contentDescription = "Online Pediatric Consultation",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(135.dp)
                    .clip(RoundedCornerShape(18.dp))
            )
        }

        item {
            SectionHeader("Pediatric Specialist Network & Telemedicine", "Verified MCT / KMPDC / TNMC clinicians • Encrypted medical consultations")
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                specialties.forEach { sp ->
                    FilterChip(selected = specialtyFilter == sp, onClick = { specialtyFilter = sp }, label = { Text(sp) })
                }
            }
        }

        if (consultations.isNotEmpty()) {
            item {
                SectionHeader("Your Active Consultations & Prescriptions")
            }
            items(consultations, key = { it.id }) { consult ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftLightBlue),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${consult.doctorName} (${consult.consultationMode.uppercase()})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(consult.status.uppercase(), style = MaterialTheme.typography.labelSmall, color = PrimaryBlue, fontWeight = FontWeight.Bold)
                        }
                        Text("Patient: ${consult.childName} • Slot: ${consult.scheduledSlot}", style = MaterialTheme.typography.bodySmall)
                        Text("Summary: ${consult.symptomsSummary}", style = MaterialTheme.typography.bodySmall)
                        if (consult.prescriptionText.isNotBlank()) {
                            Text("Prescription: ${consult.prescriptionText}", style = MaterialTheme.typography.bodySmall, color = RiskGreen, fontWeight = FontWeight.SemiBold)
                        }
                        if (consult.referralSpecialty.isNotBlank()) {
                            Text("Specialist Referral: ${consult.referralSpecialty}", style = MaterialTheme.typography.labelMedium, color = HealthcareTeal)
                        }
                        Button(
                            onClick = {
                                onOpenChat(consult.id)
                                activeChatConsult = consult
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open Encrypted Consultation Chat")
                        }
                    }
                }
            }
        }

        items(doctors, key = { it.id }) { doc ->
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(doc.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = HealthcareTeal, modifier = Modifier.size(18.dp))
                    }
                    Text("${doc.specialty} • ${doc.hospital} (${doc.country})", style = MaterialTheme.typography.bodySmall, color = PrimaryBlue)
                    Text("${doc.licenseBadge} • Languages: ${doc.languages}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Next Slot: ${doc.nextAvailable} • Fee: ${doc.consultationFeeTzs} ${country.currencyCode}", style = MaterialTheme.typography.bodySmall)
                    Button(
                        onClick = { bookingDoctor = doc },
                        enabled = activeChild != null,
                        modifier = Modifier.fillMaxWidth().testTag("book_doc_${doc.id}")
                    ) {
                        Icon(Icons.Filled.VideoCall, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (activeChild == null) "Register a Child First" else "Book Consultation (${activeChild.fullName})")
                    }
                }
            }
        }
    }

    if (bookingDoctor != null && activeChild != null) {
        val doc = bookingDoctor!!
        var mode by remember { mutableStateOf("video") }
        var notes by remember { mutableStateOf(prefillNotes) }
        var attachment by remember { mutableStateOf("Child EMR + Symptom Summary") }

        AlertDialog(
            onDismissRequest = { bookingDoctor = null },
            title = { Text("Book ${doc.fullName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Child: ${activeChild.fullName} • Slot: ${doc.nextAvailable}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("video", "voice", "chat").forEach { m ->
                            FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.uppercase()) })
                        }
                    }
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Symptoms / Reason for Visit") }, minLines = 2)
                    OutlinedTextField(value = attachment, onValueChange = { attachment = it }, label = { Text("Shared Media / Cry / Lab Attachment Note") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    onBook(activeChild, doc, mode, doc.nextAvailable, notes.ifBlank { "General pediatric review" }, attachment)
                    bookingDoctor = null
                }) { Text("Confirm Booking") }
            },
            dismissButton = {
                TextButton(onClick = { bookingDoctor = null }) { Text("Cancel") }
            }
        )
    }

    if (activeChatConsult != null) {
        val consult = activeChatConsult!!
        var msgInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { activeChatConsult = null },
            title = { Text("Encrypted Chat: ${consult.doctorName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Text("Private medical thread for ${consult.childName} • Parent: $parentName", style = MaterialTheme.typography.labelSmall, color = HealthcareTeal)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.height(220.dp)) {
                        if (activeMessages.isEmpty()) {
                            Text("Send symptoms, cry notes, or questions to your doctor.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            activeMessages.takeLast(6).forEach { msg ->
                                Surface(
                                    color = if (msg.senderRole == "parent") SoftLightBlue else SoftTealTint,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("${msg.senderName}: ${msg.body}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp))
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = msgInput,
                            onValueChange = { msgInput = it },
                            placeholder = { Text("Write secure message...") },
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            if (msgInput.isNotBlank()) {
                                onSendMessage(consult.id, msgInput)
                                msgInput = ""
                            }
                        }) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { activeChatConsult = null }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun PharmacyMarketplaceTab(
    country: CountryConfig,
    activeChild: ChildProfile?,
    orders: List<PharmacyOrder>,
    onPlaceOrder: (String, PharmacyListing, Long, String, String, String) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var orderingItem by remember { mutableStateOf<PharmacyListing?>(null) }

    val catalog = TanzaniaHealthDirectories.pharmacyCatalog.filter {
        query.isBlank() || it.medicineName.contains(query, true) || it.pharmacyName.contains(query, true) || it.region.contains(query, true)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            SectionHeader("Licensed Online Pharmacy Marketplace", "TMDA-compliant pharmacies • Prescription verification enforced")
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search medicines, pharmacies, or regions (e.g. ORS, Dar es Salaam)") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (orders.isNotEmpty()) {
            item {
                SectionHeader("Your Pharmacy Orders")
            }
            items(orders, key = { it.id }) { ord ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftTealTint),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("${ord.medicineName} (x${ord.quantity}) • ${ord.totalTzs} ${country.currencyCode}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("${ord.pharmacyName} • Status: ${ord.status.uppercase()}", style = MaterialTheme.typography.bodySmall, color = PrimaryBlue)
                    }
                }
            }
        }

        items(catalog, key = { it.id }) { item ->
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.LocalPharmacy, contentDescription = null, tint = HealthcareTeal, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(item.medicineName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Text("${item.priceTzs} ${country.currencyCode}", style = MaterialTheme.typography.titleSmall, color = PrimaryBlue, fontWeight = FontWeight.Bold)
                    }
                    Text("${item.pharmacyName} (${item.region}) • ${item.licenseCode}", style = MaterialTheme.typography.bodySmall)
                    Text("${item.dosageForm} • ${if (item.requiresPrescription) "Prescription Required (Rx)" else "Over-the-Counter"}", style = MaterialTheme.typography.labelMedium, color = if (item.requiresPrescription) RiskOrange else RiskGreen)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${item.phone}"))) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Call Pharmacist")
                        }
                        Button(
                            onClick = { orderingItem = item },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Order Now")
                        }
                    }
                }
            }
        }
    }

    if (orderingItem != null) {
        val listing = orderingItem!!
        var rxNote by remember { mutableStateOf("") }
        var address by remember { mutableStateOf(activeChild?.location ?: "Dar es Salaam") }
        var deliveryMode by remember { mutableStateOf("delivery") }

        AlertDialog(
            onDismissRequest = { orderingItem = null },
            title = { Text("Order: ${listing.medicineName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${listing.pharmacyName} • ${listing.priceTzs} ${country.currencyCode}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = deliveryMode == "delivery", onClick = { deliveryMode = "delivery" }, label = { Text("Delivery") })
                        FilterChip(selected = deliveryMode == "pickup", onClick = { deliveryMode = "pickup" }, label = { Text("Pickup") })
                    }
                    if (listing.requiresPrescription) {
                        OutlinedTextField(
                            value = rxNote,
                            onValueChange = { rxNote = it },
                            label = { Text("Doctor Prescription Ref / Clinician Name (Required)") }
                        )
                    }
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Delivery Address / Notes") })
                }
            },
            confirmButton = {
                Button(
                    enabled = !listing.requiresPrescription || rxNote.isNotBlank(),
                    onClick = {
                        onPlaceOrder(activeChild?.fullName ?: "Child", listing, 1L, rxNote, deliveryMode, address)
                        orderingItem = null
                    }
                ) { Text("Submit Order") }
            },
            dismissButton = {
                TextButton(onClick = { orderingItem = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun EducationOfficialTab(
    language: AppLanguage,
    country: CountryConfig,
    bulletins: List<OfficialHealthBulletin>
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            SectionHeader(
                title = "Official Health Information & Child Education",
                subtitle = "${country.ministryName} • WHO • UNICEF • NMCP"
            )
        }

        if (bulletins.isNotEmpty()) {
            item {
                Text("Live Official Health Bulletins", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = PrimaryBlue)
            }
            items(bulletins, key = { it.id }) { bul ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftLightBlue),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(bul.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("Source: ${bul.source} • Updated: ${bul.publishedDate}", style = MaterialTheme.typography.labelSmall, color = HealthcareTeal)
                        Text(bul.summary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        items(TanzaniaHealthDirectories.educationLibrary, key = { it.id }) { item ->
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            text = if (language == AppLanguage.KISWAHILI) item.categorySw else item.categoryEn,
                            style = MaterialTheme.typography.labelLarge,
                            color = PrimaryBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Text(item.targetAgeLabel, style = MaterialTheme.typography.labelSmall, color = HealthcareTeal)
                    }
                    Text(
                        text = if (language == AppLanguage.KISWAHILI) item.titleSw else item.titleEn,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (language == AppLanguage.KISWAHILI) item.summarySw else item.summaryEn,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Verified Source: ${item.source} • Published: ${item.publishedDate}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
