package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.core.AppLanguage
import com.example.core.CountryConfig
import com.example.core.TotoStrings
import com.example.data.AgeGroup
import com.example.data.CareNotification
import com.example.data.ChildProfile
import com.example.data.HealthAssessment
import com.example.data.RiskLevel
import com.example.data.VaccinationRecord
import com.example.ui.components.ChildSelectorBar
import com.example.ui.components.EmptyNoticeCard
import com.example.ui.components.MedicalDisclaimerBanner
import com.example.ui.components.RiskLevelBadge
import com.example.ui.components.SectionHeader
import com.example.ui.theme.DarkNavy
import com.example.ui.theme.HealthcareTeal
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RiskRed
import com.example.ui.theme.SoftLightBlue
import com.example.ui.theme.SoftTealTint

data class QuickActionTarget(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tint: Color,
    val testTag: String,
    val onClick: () -> Unit
)

@Composable
fun HomeScreen(
    parentName: String,
    country: CountryConfig,
    language: AppLanguage,
    strings: TotoStrings,
    children: List<ChildProfile>,
    activeChild: ChildProfile?,
    vaccinations: List<VaccinationRecord>,
    assessments: List<HealthAssessment>,
    notifications: List<CareNotification>,
    onSelectChild: (String) -> Unit,
    onOpenAddChild: () -> Unit,
    onOpenEmergency: () -> Unit,
    onNavigateAssess: (Int) -> Unit,
    onNavigateClinic: (Int) -> Unit,
    onNavigateServices: (Int) -> Unit,
    onMarkNotificationRead: (String) -> Unit
) {
    val activeVaccinations = vaccinations.filter { activeChild == null || it.childId == activeChild.id }
    val upcomingCount = activeVaccinations.count { it.status == "upcoming" || it.status == "missed" }
    val latestAssessment = assessments.firstOrNull { activeChild == null || it.childId == activeChild.id }

    val quickActions = listOf(
        QuickActionTarget(
            title = strings.checkSymptoms,
            subtitle = "0–13y AI Triage",
            icon = Icons.Filled.MedicalServices,
            tint = PrimaryBlue,
            testTag = "qa_symptoms",
            onClick = { onNavigateAssess(0) }
        ),
        QuickActionTarget(
            title = strings.recordBabyCry,
            subtitle = "Audio & Pattern AI",
            icon = Icons.Filled.GraphicEq,
            tint = HealthcareTeal,
            testTag = "qa_baby_cry",
            onClick = { onNavigateAssess(1) }
        ),
        QuickActionTarget(
            title = strings.aiAssistant,
            subtitle = "EN / Kiswahili Chat",
            icon = Icons.Filled.Psychology,
            tint = PrimaryBlue,
            testTag = "qa_ai_assistant",
            onClick = { onNavigateAssess(2) }
        ),
        QuickActionTarget(
            title = strings.nearbyHospitals,
            subtitle = "GPS & 24/7 Care",
            icon = Icons.Filled.LocalHospital,
            tint = RiskRed,
            testTag = "qa_hospitals",
            onClick = { onNavigateServices(0) }
        ),
        QuickActionTarget(
            title = strings.talkToDoctor,
            subtitle = "Video, Voice & Chat",
            icon = Icons.Filled.VideoCall,
            tint = HealthcareTeal,
            testTag = "qa_doctor",
            onClick = { onNavigateServices(1) }
        ),
        QuickActionTarget(
            title = strings.clinicAndVaccines,
            subtitle = "$upcomingCount due • MoH EPI",
            icon = Icons.Filled.Vaccines,
            tint = PrimaryBlue,
            testTag = "qa_vaccines",
            onClick = { onNavigateClinic(1) }
        ),
        QuickActionTarget(
            title = strings.growthMonitor,
            subtitle = "Weight & Height",
            icon = Icons.AutoMirrored.Filled.ShowChart,
            tint = HealthcareTeal,
            testTag = "qa_growth",
            onClick = { onNavigateClinic(2) }
        ),
        QuickActionTarget(
            title = strings.pharmacyMarket,
            subtitle = "Licensed Delivery",
            icon = Icons.Filled.LocalPharmacy,
            tint = PrimaryBlue,
            testTag = "qa_pharmacy",
            onClick = { onNavigateServices(2) }
        ),
        QuickActionTarget(
            title = strings.healthEducation,
            subtitle = "WHO & MoH Guides",
            icon = Icons.AutoMirrored.Filled.MenuBook,
            tint = HealthcareTeal,
            testTag = "qa_education",
            onClick = { onNavigateServices(3) }
        ),
        QuickActionTarget(
            title = strings.medicalRecords,
            subtitle = "EMR & Export",
            icon = Icons.Filled.FolderShared,
            tint = DarkNavy,
            testTag = "qa_records",
            onClick = { onNavigateClinic(0) }
        )
    )

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Hero Mission & Emergency SOS Header Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Box {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_family),
                            contentDescription = "TOTOCARE family care",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(155.dp)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(155.dp)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, DarkNavy.copy(alpha = 0.78f))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(14.dp)
                        ) {
                            Text(
                                text = "${country.flagEmoji} ${country.name} • $parentName",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                            Text(
                                text = strings.brandTagline,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (language == AppLanguage.KISWAHILI) "Hali ya Dharura ya Mtoto?" else "Child Emergency?",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = RiskRed
                            )
                            Text(
                                text = if (language == AppLanguage.KISWAHILI)
                                    "Maelekezo ya haraka, hospitali & simu ${country.emergencyNumber}"
                                else
                                    "Instant triage, nearest ER & ${country.emergencyNumber} dispatch",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Button(
                            onClick = onOpenEmergency,
                            colors = ButtonDefaults.buttonColors(containerColor = RiskRed),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("home_sos_button")
                        ) {
                            Icon(Icons.Filled.Emergency, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.sosEmergency, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. Child Profile Switcher & Active Child Card
        item {
            ChildSelectorBar(
                children = children,
                selectedChildId = activeChild?.id,
                onSelectChild = onSelectChild,
                onAddChildClick = onOpenAddChild,
                addLabel = strings.addChild
            )
        }

        item {
            if (activeChild == null) {
                EmptyNoticeCard(
                    title = strings.addChild,
                    body = strings.noChildYet,
                    modifier = Modifier.clickable(onClick = onOpenAddChild)
                )
            } else {
                val ageEnum = AgeGroup.fromCode(activeChild.ageGroup)
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftLightBlue),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateClinic(0) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(14.dp)
                    ) {
                        if (activeChild.photoUri.isNotBlank()) {
                            AsyncImage(
                                model = activeChild.photoUri,
                                contentDescription = activeChild.fullName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                            )
                        } else {
                            Surface(
                                color = PrimaryBlue,
                                shape = CircleShape,
                                modifier = Modifier.size(56.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.ChildCare, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeChild.fullName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkNavy
                            )
                            Text(
                                text = "${ageEnum.labelEn} (${ageEnum.rangeLabel}) • ${activeChild.gender} • Blood: ${activeChild.bloodGroup.ifBlank { "Unknown" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (activeChild.allergies.isNotBlank()) {
                                Text(
                                    text = "Allergies: ${activeChild.allergies}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RiskRed,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (latestAssessment != null) {
                            RiskLevelBadge(
                                riskLevel = RiskLevel.fromCode(latestAssessment.riskLevel),
                                language = language
                            )
                        }
                    }
                }
            }
        }

        // 3. Parent Care Hub Grid (2 columns)
        item {
            SectionHeader(
                title = if (language == AppLanguage.KISWAHILI) "Huduma za Mzazi" else "Child Healthcare Hub",
                subtitle = if (language == AppLanguage.KISWAHILI)
                    "Uchunguzi wa AI, madaktari, chanjo na duka la dawa"
                else
                    "AI triage, baby cry insights, pediatricians, vaccines & pharmacy"
            )
        }

        items(quickActions.chunked(2)) { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pair.forEach { action ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(18.dp))
                            .clickable(onClick = action.onClick)
                            .testTag(action.testTag)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(14.dp)
                        ) {
                            Surface(
                                color = action.tint.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = action.icon,
                                        contentDescription = action.title,
                                        tint = action.tint,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = action.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = action.subtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
                if (pair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }

        // 4. Smart Notifications & Reminders
        item {
            SectionHeader(
                title = strings.notifications,
                subtitle = "${country.ministryName} • Smart clinic & vaccine reminders"
            )
        }

        if (notifications.isEmpty()) {
            item {
                Surface(
                    color = SoftTealTint,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Filled.CalendarMonth, contentDescription = null, tint = HealthcareTeal)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Automatic clinic, vaccination, and consultation reminders appear here as you care for your child.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        } else {
            items(notifications.take(5), key = { it.id }) { notif ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (notif.readStatus) MaterialTheme.colorScheme.surface else SoftLightBlue
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { if (!notif.readStatus) onMarkNotificationRead(notif.id) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Icon(
                            imageVector = if (notif.readStatus) Icons.Filled.CheckCircle else Icons.Filled.NotificationsActive,
                            contentDescription = null,
                            tint = if (notif.readStatus) HealthcareTeal else PrimaryBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = notif.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(text = notif.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        item {
            MedicalDisclaimerBanner(text = strings.medicalDisclaimer)
        }
    }
}
