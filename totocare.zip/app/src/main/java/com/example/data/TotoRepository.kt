package com.example.data

import android.content.Context
import com.example.R
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class TotoRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun <T> Flow<T>.logAndRethrowFirestoreError(
        operationType: OperationType,
        path: String,
        uid: String
    ): Flow<T> = catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
        throw error
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Refusing cross-user profile observation" }
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { it.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .logAndRethrowFirestoreError(OperationType.GET, path, uid)
        )
    }

    fun observeChildren(userId: String): Flow<List<ChildProfile>> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Refusing cross-user children observation" }
        val path = "users/$uid/children"
        emitAll(
            db.collection("users").document(uid).collection("children")
                .snapshots()
                .map { snap ->
                    snap.toObjects(ChildProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.fullName }
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    fun observeVaccinations(userId: String): Flow<List<VaccinationRecord>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "users/$uid/vaccinations"
        emitAll(
            db.collection("users").document(uid).collection("vaccinations")
                .snapshots()
                .map { snap ->
                    snap.toObjects(VaccinationRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    fun observeGrowthLogs(userId: String): Flow<List<GrowthMeasurement>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "users/$uid/growthLogs"
        emitAll(
            db.collection("users").document(uid).collection("growthLogs")
                .snapshots()
                .map { snap ->
                    snap.toObjects(GrowthMeasurement::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.recordedDateText }
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    fun observeAssessments(userId: String): Flow<List<HealthAssessment>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "users/$uid/assessments"
        emitAll(
            db.collection("users").document(uid).collection("assessments")
                .snapshots()
                .map { snap ->
                    snap.toObjects(HealthAssessment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    fun observeNotifications(userId: String): Flow<List<CareNotification>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "users/$uid/notifications"
        emitAll(
            db.collection("users").document(uid).collection("notifications")
                .snapshots()
                .map { snap ->
                    snap.toObjects(CareNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    fun observeConsultations(userId: String): Flow<List<ConsultationRecord>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "consultations"
        emitAll(
            db.collection("consultations")
                .whereEqualTo("parentUid", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ConsultationRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    fun observeConsultationMessages(consultationId: String, userId: String): Flow<List<ConsultationMessage>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "consultations/$consultationId/messages"
        emitAll(
            db.collection("consultations").document(consultationId).collection("messages")
                .whereEqualTo("parentUid", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ConsultationMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt?.seconds ?: 0L }
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    fun observePharmacyOrders(userId: String): Flow<List<PharmacyOrder>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "pharmacyOrders"
        emitAll(
            db.collection("pharmacyOrders")
                .whereEqualTo("parentUid", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(PharmacyOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    fun observeMyProviderApplication(userId: String): Flow<ProviderApplication?> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "providerApplications/$uid"
        emitAll(
            db.collection("providerApplications").document(uid)
                .snapshots()
                .map { it.toObject(ProviderApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .logAndRethrowFirestoreError(OperationType.GET, path, uid)
        )
    }

    fun observePublishedBulletins(userId: String): Flow<List<OfficialHealthBulletin>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "healthBulletins"
        emitAll(
            db.collection("healthBulletins")
                .whereEqualTo("published", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(OfficialHealthBulletin::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .logAndRethrowFirestoreError(OperationType.LIST, path, uid)
        )
    }

    suspend fun ensureUserProfile(
        fullName: String,
        email: String
    ): Result<Unit> {
        var docPath = "users/unauthenticated"
        return try {
            val uid = requireUserId()
            val ref = db.collection("users").document(uid)
            docPath = ref.path
            val existing = ref.get().await()
            if (!existing.exists()) {
                val safeName = fullName.trim().ifBlank { "TOTOCARE Parent" }.take(100)
                val payload = mapOf(
                    "userId" to uid,
                    "fullName" to safeName,
                    "email" to email.trim().take(120),
                    "phone" to "",
                    "caregiverRole" to "parent",
                    "language" to "en",
                    "countryCode" to "TZ",
                    "workspaceRole" to "parent",
                    "emergencyContactName" to "",
                    "emergencyContactPhone" to "",
                    "twoFactorEnabled" to true,
                    "notificationsEnabled" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                ref.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateUserSettings(
        fullName: String,
        phone: String,
        caregiverRole: String,
        language: String,
        countryCode: String,
        workspaceRole: String,
        emergencyContactName: String,
        emergencyContactPhone: String,
        twoFactorEnabled: Boolean,
        notificationsEnabled: Boolean
    ): Result<Unit> {
        var docPath = "users/unauthenticated"
        return try {
            val uid = requireUserId()
            val ref = db.collection("users").document(uid)
            docPath = ref.path
            val safeName = fullName.trim().ifBlank { "TOTOCARE Parent" }.take(100)
            ref.update(
                mapOf(
                    "fullName" to safeName,
                    "phone" to phone.trim().take(30),
                    "caregiverRole" to caregiverRole,
                    "language" to language,
                    "countryCode" to countryCode,
                    "workspaceRole" to workspaceRole,
                    "emergencyContactName" to emergencyContactName.trim().take(80),
                    "emergencyContactPhone" to emergencyContactPhone.trim().take(30),
                    "twoFactorEnabled" to twoFactorEnabled,
                    "notificationsEnabled" to notificationsEnabled,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun addChildProfile(
        child: ChildProfile,
        seedTanzaniaEpi: Boolean = true
    ): Result<String> {
        var docPath = "users/unauthenticated/children"
        return try {
            val uid = requireUserId()
            val ref = db.collection("users").document(uid).collection("children").document()
            docPath = ref.path
            val cleanName = child.fullName.trim().take(100)
            require(cleanName.isNotEmpty()) { "Child name cannot be empty." }
            val safeAgeMonths = child.ageMonths.coerceIn(0L, 180L)
            val ageGroup = AgeGroup.fromMonths(safeAgeMonths).code
            val payload = mapOf(
                "userId" to uid,
                "fullName" to cleanName,
                "dobText" to child.dobText.trim().ifBlank { "2024-01-01" }.take(30),
                "ageMonths" to safeAgeMonths,
                "ageGroup" to ageGroup,
                "gender" to child.gender.trim().ifBlank { "Female" }.take(20),
                "birthWeightKg" to child.birthWeightKg.coerceIn(0.4, 10.0),
                "bloodGroup" to child.bloodGroup.trim().take(12),
                "location" to child.location.trim().take(100),
                "allergies" to child.allergies.trim().take(400),
                "previousIllnesses" to child.previousIllnesses.trim().take(400),
                "existingConditions" to child.existingConditions.trim().take(400),
                "medications" to child.medications.trim().take(400),
                "emergencyContactName" to child.emergencyContactName.trim().take(80),
                "emergencyContactPhone" to child.emergencyContactPhone.trim().take(30),
                "photoUri" to child.photoUri.trim().take(500),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            ref.set(payload).await()

            if (seedTanzaniaEpi) {
                TanzaniaHealthDirectories.tanzaniaEpiSchedule.forEach { tpl ->
                    val vacRef = db.collection("users").document(uid).collection("vaccinations").document()
                    vacRef.set(
                        mapOf(
                            "userId" to uid,
                            "childId" to ref.id,
                            "childName" to cleanName,
                            "vaccineName" to tpl.vaccineName.take(100),
                            "ageScheduleLabel" to tpl.ageScheduleLabel.take(60),
                            "doseLabel" to tpl.doseLabel.take(40),
                            "status" to tpl.defaultStatus,
                            "scheduledDateText" to "Schedule: ${tpl.ageScheduleLabel}",
                            "administeredDateText" to if (tpl.defaultStatus == "completed") "Verified on card" else "",
                            "clinicName" to child.location.ifBlank { "Tanzania RCH Clinic" }.take(100),
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
                addNotificationInternal(
                    uid = uid,
                    childId = ref.id,
                    title = "Child Profile & Tanzania EPI Ready: $cleanName",
                    body = "Immunization schedule and growth tracking are active for $cleanName.",
                    category = "vaccine"
                )
            }
            Result.success(ref.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateChildMedicalDetails(
        childId: String,
        allergies: String,
        existingConditions: String,
        medications: String,
        emergencyContactName: String,
        emergencyContactPhone: String,
        photoUri: String
    ): Result<Unit> {
        var docPath = "users/unauthenticated/children/$childId"
        return try {
            val uid = requireUserId()
            require(childId.isNotBlank())
            val ref = db.collection("users").document(uid).collection("children").document(childId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "allergies" to allergies.trim().take(400),
                    "existingConditions" to existingConditions.trim().take(400),
                    "medications" to medications.trim().take(400),
                    "emergencyContactName" to emergencyContactName.trim().take(80),
                    "emergencyContactPhone" to emergencyContactPhone.trim().take(30),
                    "photoUri" to photoUri.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateVaccinationStatus(
        vaccinationId: String,
        status: String,
        administeredDateText: String,
        clinicName: String
    ): Result<Unit> {
        var docPath = "users/unauthenticated/vaccinations/$vaccinationId"
        return try {
            val uid = requireUserId()
            require(vaccinationId.isNotBlank())
            val ref = db.collection("users").document(uid).collection("vaccinations").document(vaccinationId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "status" to status,
                    "administeredDateText" to administeredDateText.trim().take(30),
                    "clinicName" to clinicName.trim().take(100),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun addGrowthMeasurement(
        childId: String,
        childName: String,
        weightKg: Double,
        heightCm: Double,
        headCircumferenceCm: Double,
        recordedDateText: String,
        milestoneNote: String
    ): Result<Unit> {
        var docPath = "users/unauthenticated/growthLogs"
        return try {
            val uid = requireUserId()
            val ref = db.collection("users").document(uid).collection("growthLogs").document()
            docPath = ref.path
            ref.set(
                mapOf(
                    "userId" to uid,
                    "childId" to childId,
                    "childName" to childName.trim().take(100),
                    "weightKg" to weightKg.coerceIn(0.3, 150.0),
                    "heightCm" to heightCm.coerceIn(20.0, 220.0),
                    "headCircumferenceCm" to headCircumferenceCm.coerceIn(15.0, 80.0),
                    "recordedDateText" to recordedDateText.trim().ifBlank { "2026-11-24" }.take(30),
                    "milestoneNote" to milestoneNote.trim().take(300),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun saveHealthAssessment(
        childId: String,
        childName: String,
        kind: String,
        ageGroup: String,
        symptomsSummary: String,
        riskLevel: String,
        aiExplanation: String,
        nextSteps: String,
        emergencyTriggered: Boolean
    ): Result<Unit> {
        var docPath = "users/unauthenticated/assessments"
        return try {
            val uid = requireUserId()
            val ref = db.collection("users").document(uid).collection("assessments").document()
            docPath = ref.path
            ref.set(
                mapOf(
                    "userId" to uid,
                    "childId" to childId,
                    "childName" to childName.trim().take(100),
                    "kind" to kind,
                    "ageGroup" to ageGroup,
                    "symptomsSummary" to symptomsSummary.trim().ifBlank { "Audio/symptom review" }.take(1000),
                    "riskLevel" to riskLevel,
                    "aiExplanation" to aiExplanation.trim().ifBlank { "Assessment logged." }.take(3000),
                    "nextSteps" to nextSteps.trim().ifBlank { "Monitor and consult a clinician." }.take(2000),
                    "emergencyTriggered" to emergencyTriggered,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            if (riskLevel == "RED" || riskLevel == "ORANGE") {
                addNotificationInternal(
                    uid = uid,
                    childId = childId,
                    title = "$riskLevel Alert for $childName",
                    body = nextSteps.take(450),
                    category = "emergency"
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> {
        var docPath = "users/unauthenticated/notifications/$notificationId"
        return try {
            val uid = requireUserId()
            val ref = db.collection("users").document(uid).collection("notifications").document(notificationId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "readStatus" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun createConsultation(
        parentName: String,
        childId: String,
        childName: String,
        doctor: PediatricSpecialist,
        mode: String,
        scheduledSlot: String,
        symptomsSummary: String,
        attachmentSummary: String
    ): Result<String> {
        var docPath = "consultations"
        return try {
            val uid = requireUserId()
            val ref = db.collection("consultations").document()
            docPath = ref.path
            ref.set(
                mapOf(
                    "parentUid" to uid,
                    "parentName" to parentName.trim().ifBlank { "TOTOCARE Parent" }.take(100),
                    "childId" to childId,
                    "childName" to childName.trim().take(100),
                    "doctorId" to doctor.id,
                    "doctorName" to doctor.fullName.take(100),
                    "specialty" to doctor.specialty.take(80),
                    "consultationMode" to mode,
                    "scheduledSlot" to scheduledSlot.trim().take(60),
                    "symptomsSummary" to symptomsSummary.trim().ifBlank { "Pediatric consultation requested" }.take(1000),
                    "attachmentSummary" to attachmentSummary.trim().take(500),
                    "status" to "requested",
                    "doctorNotes" to "",
                    "prescriptionText" to "",
                    "referralSpecialty" to "",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            addNotificationInternal(
                uid = uid,
                childId = childId,
                title = "Consultation Booked: ${doctor.fullName}",
                body = "$mode visit for $childName ($scheduledSlot)",
                category = "consultation"
            )
            Result.success(ref.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun sendConsultationMessage(
        consultationId: String,
        senderName: String,
        senderRole: String,
        body: String,
        attachmentLabel: String = ""
    ): Result<Unit> {
        var docPath = "consultations/$consultationId/messages"
        return try {
            val uid = requireUserId()
            val ref = db.collection("consultations").document(consultationId).collection("messages").document()
            docPath = ref.path
            ref.set(
                mapOf(
                    "parentUid" to uid,
                    "senderUid" to uid,
                    "senderName" to senderName.trim().ifBlank { "User" }.take(100),
                    "senderRole" to senderRole,
                    "body" to body.trim().take(1000),
                    "attachmentLabel" to attachmentLabel.trim().take(200),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateConsultationClinicalRecord(
        consultationId: String,
        status: String,
        doctorNotes: String,
        prescriptionText: String,
        referralSpecialty: String
    ): Result<Unit> {
        var docPath = "consultations/$consultationId"
        return try {
            requireUserId()
            val ref = db.collection("consultations").document(consultationId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "status" to status,
                    "doctorNotes" to doctorNotes.trim().take(1500),
                    "prescriptionText" to prescriptionText.trim().take(1000),
                    "referralSpecialty" to referralSpecialty.trim().take(120),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun placePharmacyOrder(
        parentName: String,
        childName: String,
        listing: PharmacyListing,
        quantity: Long,
        prescriptionNote: String,
        deliveryMode: String,
        deliveryAddress: String
    ): Result<Unit> {
        var docPath = "pharmacyOrders"
        return try {
            val uid = requireUserId()
            val ref = db.collection("pharmacyOrders").document()
            docPath = ref.path
            val safeQty = quantity.coerceIn(1L, 50L)
            ref.set(
                mapOf(
                    "parentUid" to uid,
                    "parentName" to parentName.trim().ifBlank { "TOTOCARE Parent" }.take(100),
                    "childName" to childName.trim().ifBlank { "Child" }.take(100),
                    "pharmacyName" to listing.pharmacyName.take(120),
                    "medicineName" to listing.medicineName.take(120),
                    "quantity" to safeQty,
                    "totalTzs" to (listing.priceTzs * safeQty),
                    "requiresPrescription" to listing.requiresPrescription,
                    "prescriptionNote" to prescriptionNote.trim().take(500),
                    "deliveryMode" to deliveryMode,
                    "deliveryAddress" to deliveryAddress.trim().take(200),
                    "status" to "pending_verification",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updatePharmacyOrderStatus(orderId: String, status: String): Result<Unit> {
        var docPath = "pharmacyOrders/$orderId"
        return try {
            requireUserId()
            val ref = db.collection("pharmacyOrders").document(orderId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "status" to status,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun submitProviderApplication(
        providerType: String,
        applicantName: String,
        facilityName: String,
        licenseNumber: String,
        specialty: String,
        region: String
    ): Result<Unit> {
        var docPath = "providerApplications/unauthenticated"
        return try {
            val uid = requireUserId()
            val ref = db.collection("providerApplications").document(uid)
            docPath = ref.path
            val existing = ref.get().await()
            if (!existing.exists()) {
                ref.set(
                    mapOf(
                        "userId" to uid,
                        "providerType" to providerType,
                        "applicantName" to applicantName.trim().take(100),
                        "facilityName" to facilityName.trim().take(120),
                        "licenseNumber" to licenseNumber.trim().take(60),
                        "specialty" to specialty.trim().take(80),
                        "region" to region.trim().take(80),
                        "verificationStatus" to "pending",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.update(
                    mapOf(
                        "providerType" to providerType,
                        "applicantName" to applicantName.trim().take(100),
                        "facilityName" to facilityName.trim().take(120),
                        "licenseNumber" to licenseNumber.trim().take(60),
                        "specialty" to specialty.trim().take(80),
                        "region" to region.trim().take(80),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun publishHealthBulletin(
        title: String,
        source: String,
        publishedDate: String,
        category: String,
        summary: String,
        language: String
    ): Result<Unit> {
        var docPath = "healthBulletins"
        return try {
            requireUserId()
            val ref = db.collection("healthBulletins").document()
            docPath = ref.path
            ref.set(
                mapOf(
                    "title" to title.trim().take(160),
                    "source" to source.trim().take(100),
                    "publishedDate" to publishedDate.trim().take(30),
                    "category" to category.trim().take(60),
                    "summary" to summary.trim().take(1500),
                    "language" to language,
                    "published" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    private suspend fun addNotificationInternal(
        uid: String,
        childId: String,
        title: String,
        body: String,
        category: String
    ) {
        val notifRef = db.collection("users").document(uid).collection("notifications").document()
        notifRef.set(
            mapOf(
                "userId" to uid,
                "childId" to childId,
                "title" to title.take(140),
                "body" to body.take(500),
                "category" to category,
                "readStatus" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }
}
