package com.example.data

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class HealthcareFacility(
    val id: String,
    val name: String,
    val facilityType: String,
    val cityRegion: String,
    val address: String,
    val phone: String,
    val hours: String,
    val services: List<String>,
    val hasEmergencyUnit: Boolean,
    val hasPediatricIcu: Boolean,
    val latitude: Double,
    val longitude: Double
)

data class PediatricSpecialist(
    val id: String,
    val fullName: String,
    val specialty: String,
    val country: String,
    val hospital: String,
    val licenseBadge: String,
    val languages: String,
    val nextAvailable: String,
    val consultationFeeTzs: Long
)

data class PharmacyListing(
    val id: String,
    val pharmacyName: String,
    val region: String,
    val licenseCode: String,
    val medicineName: String,
    val dosageForm: String,
    val priceTzs: Long,
    val inStock: Boolean,
    val requiresPrescription: Boolean,
    val phone: String
)

data class EpiVaccineTemplate(
    val vaccineName: String,
    val ageScheduleLabel: String,
    val doseLabel: String,
    val defaultStatus: String
)

data class HealthEducationItem(
    val id: String,
    val categoryEn: String,
    val categorySw: String,
    val titleEn: String,
    val titleSw: String,
    val summaryEn: String,
    val summarySw: String,
    val source: String,
    val publishedDate: String,
    val targetAgeLabel: String
)

object TanzaniaHealthDirectories {

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    val facilities = listOf(
        HealthcareFacility(
            id = "fac_mnh",
            name = "Muhimbili National Hospital — Paediatric Block",
            facilityType = "Pediatric Referral Hospital",
            cityRegion = "Dar es Salaam",
            address = "Kalenga St, Upanga West, Dar es Salaam",
            phone = "+255222151599",
            hours = "Open 24 Hours (Emergency & PICU)",
            services = listOf("24/7 Pediatric Emergency", "Neonatal ICU", "Pediatric Surgery", "EPI Immunization"),
            hasEmergencyUnit = true,
            hasPediatricIcu = true,
            latitude = -6.8075,
            longitude = 39.2721
        ),
        HealthcareFacility(
            id = "fac_agakhan",
            name = "The Aga Khan Hospital Dar es Salaam",
            facilityType = "Private Pediatric & General Hospital",
            cityRegion = "Dar es Salaam",
            address = "Barack Obama Dr, Dar es Salaam",
            phone = "+255222115151",
            hours = "Open 24 Hours",
            services = listOf("24/7 Emergency", "Pediatrics", "Neonatology", "Diagnostics & Lab"),
            hasEmergencyUnit = true,
            hasPediatricIcu = true,
            latitude = -6.8099,
            longitude = 39.2932
        ),
        HealthcareFacility(
            id = "fac_ccbrt",
            name = "CCBRT Maternal & Newborn Wing",
            facilityType = "Specialized Hospital",
            cityRegion = "Dar es Salaam",
            address = "Msasani Peninsula, Dar es Salaam",
            phone = "+255222601543",
            hours = "24/7 Maternity & Neonatal Care",
            services = listOf("Neonatal Care", "Pediatric Rehabilitation", "Outpatient Clinic"),
            hasEmergencyUnit = true,
            hasPediatricIcu = false,
            latitude = -6.7641,
            longitude = 39.2612
        ),
        HealthcareFacility(
            id = "fac_bugando",
            name = "Bugando Medical Centre",
            facilityType = "Zonal Referral Hospital",
            cityRegion = "Mwanza",
            address = "Wurzburg Rd, Bugando Hill, Mwanza",
            phone = "+255282540610",
            hours = "Open 24 Hours",
            services = listOf("Pediatric Emergency", "NICU", "Pediatric Cardiology", "EPI Clinic"),
            hasEmergencyUnit = true,
            hasPediatricIcu = true,
            latitude = -2.5284,
            longitude = 32.9056
        ),
        HealthcareFacility(
            id = "fac_kcmc",
            name = "Kilimanjaro Christian Medical Centre (KCMC)",
            facilityType = "Referral Hospital",
            cityRegion = "Moshi / Kilimanjaro",
            address = "Sokoine Rd, Moshi",
            phone = "+255272754377",
            hours = "Open 24 Hours",
            services = listOf("Pediatrics & Child Health", "Neonatal Unit", "Pediatric Dermatology"),
            hasEmergencyUnit = true,
            hasPediatricIcu = true,
            latitude = -3.3210,
            longitude = 37.3282
        ),
        HealthcareFacility(
            id = "fac_bmh",
            name = "Benjamin Mkapa Hospital",
            facilityType = "National Referral Hospital",
            cityRegion = "Dodoma",
            address = "UDOM Campus Rd, Dodoma",
            phone = "+255262963710",
            hours = "Open 24 Hours",
            services = listOf("24/7 Emergency", "Pediatric Clinic", "Nutrition & Growth Unit"),
            hasEmergencyUnit = true,
            hasPediatricIcu = true,
            latitude = -6.2089,
            longitude = 35.8054
        ),
        HealthcareFacility(
            id = "fac_almc",
            name = "Arusha Lutheran Medical Centre (Selian)",
            facilityType = "Regional Pediatric Clinic & Hospital",
            cityRegion = "Arusha",
            address = "Nairobi Rd, Arusha",
            phone = "+255272546125",
            hours = "Open 24 Hours",
            services = listOf("Emergency Care", "Pediatrics", "RCH & Immunization"),
            hasEmergencyUnit = true,
            hasPediatricIcu = false,
            latitude = -3.3688,
            longitude = 36.6836
        ),
        HealthcareFacility(
            id = "fac_mnazi",
            name = "Mnazi Mmoja Referral Hospital",
            facilityType = "Referral Hospital",
            cityRegion = "Zanzibar",
            address = "Kaunda Rd, Stone Town, Zanzibar",
            phone = "+255242231987",
            hours = "Open 24 Hours",
            services = listOf("Pediatric Ward", "Neonatal Emergency", "RCH Immunization"),
            hasEmergencyUnit = true,
            hasPediatricIcu = true,
            latitude = -6.1672,
            longitude = 39.1932
        )
    )

    val specialists = listOf(
        PediatricSpecialist(
            id = "doc_neema",
            fullName = "Dr. Neema Mushi, MD, MMed",
            specialty = "General Pediatrician",
            country = "Tanzania",
            hospital = "Muhimbili National Hospital",
            licenseBadge = "MCT Verified #TZ-4812",
            languages = "Kiswahili, English",
            nextAvailable = "Today, 14:30 EAT",
            consultationFeeTzs = 25000L
        ),
        PediatricSpecialist(
            id = "doc_juma",
            fullName = "Dr. Juma Bakari, MD",
            specialty = "Neonatal Specialist",
            country = "Tanzania",
            hospital = "Aga Khan Hospital Dar es Salaam",
            licenseBadge = "MCT Verified #TZ-5104",
            languages = "Kiswahili, English",
            nextAvailable = "Today, 16:00 EAT",
            consultationFeeTzs = 35000L
        ),
        PediatricSpecialist(
            id = "doc_grace",
            fullName = "Dr. Grace Massawe, MD",
            specialty = "Pediatric Nutrition & Growth",
            country = "Tanzania",
            hospital = "KCMC Moshi",
            licenseBadge = "MCT Verified #TZ-3921",
            languages = "Kiswahili, English",
            nextAvailable = "Tomorrow, 09:30 EAT",
            consultationFeeTzs = 20000L
        ),
        PediatricSpecialist(
            id = "doc_kelvin",
            fullName = "Dr. Kelvin Mwanga, MD",
            specialty = "Pediatric Cardiologist",
            country = "Tanzania / Kenya",
            hospital = "Jakaya Kikwete Cardiac Institute",
            licenseBadge = "MCT & KMPDC Verified",
            languages = "English, Kiswahili",
            nextAvailable = "Tomorrow, 11:00 EAT",
            consultationFeeTzs = 45000L
        ),
        PediatricSpecialist(
            id = "doc_sarah",
            fullName = "Dr. Sarah Ochieng, MD",
            specialty = "Pediatric Neurologist",
            country = "Kenya / International",
            hospital = "East Africa Pediatric Network",
            licenseBadge = "KMPDC Verified #KE-8830",
            languages = "English, Kiswahili",
            nextAvailable = "Thu, 15:00 EAT",
            consultationFeeTzs = 40000L
        ),
        PediatricSpecialist(
            id = "doc_amina",
            fullName = "Dr. Amina Kileo, MD",
            specialty = "Pediatric Dermatologist",
            country = "Tanzania",
            hospital = "Bugando Medical Centre",
            licenseBadge = "MCT Verified #TZ-6219",
            languages = "Kiswahili, English",
            nextAvailable = "Today, 17:15 EAT",
            consultationFeeTzs = 28000L
        ),
        PediatricSpecialist(
            id = "doc_david",
            fullName = "Dr. David Nyerere, MD",
            specialty = "Pediatric Surgeon",
            country = "Tanzania",
            hospital = "Benjamin Mkapa Hospital",
            licenseBadge = "MCT Verified #TZ-3302",
            languages = "Kiswahili, English",
            nextAvailable = "Fri, 10:00 EAT",
            consultationFeeTzs = 50000L
        ),
        PediatricSpecialist(
            id = "doc_halima",
            fullName = "Nurse Halima Said, RN",
            specialty = "Child Development & RCH Nurse",
            country = "Tanzania",
            hospital = "Mnazi Mmoja Clinic",
            licenseBadge = "TNMC Verified #RN-2041",
            languages = "Kiswahili, English",
            nextAvailable = "Today, 13:00 EAT",
            consultationFeeTzs = 12000L
        )
    )

    val pharmacyCatalog = listOf(
        PharmacyListing(
            id = "ph_1",
            pharmacyName = "Kariakoo Care Pharmacy",
            region = "Dar es Salaam",
            licenseCode = "TMDA Licensed #PH-1024",
            medicineName = "Oral Rehydration Salts (ORS) + Zinc Co-Pack",
            dosageForm = "Sachets & 20mg Dispersible Tablets",
            priceTzs = 3500L,
            inStock = true,
            requiresPrescription = false,
            phone = "+255754100200"
        ),
        PharmacyListing(
            id = "ph_2",
            pharmacyName = "Upanga MedPlus Pharmacy",
            region = "Dar es Salaam",
            licenseCode = "TMDA Licensed #PH-1188",
            medicineName = "Paracetamol Pediatric Oral Suspension 120mg/5ml",
            dosageForm = "100ml Bottle with Measuring Syringe",
            priceTzs = 6500L,
            inStock = true,
            requiresPrescription = false,
            phone = "+255754330440"
        ),
        PharmacyListing(
            id = "ph_3",
            pharmacyName = "Msasani Family Pharmacy",
            region = "Dar es Salaam",
            licenseCode = "TMDA Licensed #PH-1490",
            medicineName = "Amoxicillin Dispersible Tablets 250mg (Child Pack)",
            dosageForm = "10 Dispersible Tablets",
            priceTzs = 8500L,
            inStock = true,
            requiresPrescription = true,
            phone = "+255713550660"
        ),
        PharmacyListing(
            id = "ph_4",
            pharmacyName = "Lake Zone Pediatric Pharmacy",
            region = "Mwanza",
            licenseCode = "TMDA Licensed #PH-2091",
            medicineName = "Artemether-Lumefantrine Pediatric (ALu 20/120mg)",
            dosageForm = "Dispersible Blister Pack",
            priceTzs = 9500L,
            inStock = true,
            requiresPrescription = true,
            phone = "+255784220110"
        ),
        PharmacyListing(
            id = "ph_5",
            pharmacyName = "Arusha Wellness Pharmacy",
            region = "Arusha",
            licenseCode = "TMDA Licensed #PH-3012",
            medicineName = "Saline Nasal Drops for Infants 0.9%",
            dosageForm = "15ml Dropper Bottle",
            priceTzs = 4800L,
            inStock = true,
            requiresPrescription = false,
            phone = "+255765440990"
        ),
        PharmacyListing(
            id = "ph_6",
            pharmacyName = "Dodoma Capital Pharmacy",
            region = "Dodoma",
            licenseCode = "TMDA Licensed #PH-4005",
            medicineName = "Long-Lasting Insecticidal Mosquito Net (Child Crib)",
            dosageForm = "WHO-Approved Treated Net",
            priceTzs = 14000L,
            inStock = true,
            requiresPrescription = false,
            phone = "+255714880770"
        )
    )

    val tanzaniaEpiSchedule = listOf(
        EpiVaccineTemplate("BCG (Tuberculosis)", "At Birth", "Single Dose", "completed"),
        EpiVaccineTemplate("OPV 0 (Polio Birth Dose)", "At Birth", "Dose 0", "completed"),
        EpiVaccineTemplate("OPV 1 + Penta 1 + PCV 1 + Rota 1", "6 Weeks", "Dose 1", "completed"),
        EpiVaccineTemplate("OPV 2 + Penta 2 + PCV 2 + Rota 2", "10 Weeks", "Dose 2", "upcoming"),
        EpiVaccineTemplate("OPV 3 + Penta 3 + PCV 3 + IPV", "14 Weeks", "Dose 3", "upcoming"),
        EpiVaccineTemplate("Measles-Rubella (MR 1) + Vitamin A", "9 Months", "Dose 1", "upcoming"),
        EpiVaccineTemplate("Measles-Rubella (MR 2) + Vitamin A", "18 Months", "Dose 2", "upcoming"),
        EpiVaccineTemplate("HPV (Girls) / Booster Check", "9–13 Years", "School Dose", "upcoming")
    )

    val educationLibrary = listOf(
        HealthEducationItem(
            id = "edu_danger",
            categoryEn = "Recognizing Danger Signs",
            categorySw = "Kutambua Dalili za Hatari",
            titleEn = "Emergency Red Flags in Children Under 5",
            titleSw = "Dalili za Hatari kwa Watoto Chini ya Miaka 5",
            summaryEn = "Seek immediate hospital care if a child cannot drink or breastfeed, vomits everything, has convulsions, is unusually sleepy/hard to wake, has fast or difficult breathing (chest indrawing), or fever in a newborn under 28 days.",
            summarySw = "Mpeleke mtoto hospitalini mara moja ikiwa hawezi kunyonya au kunywa, anatapika kila kitu, ana degedege, amelala sana bila kuamka kirahisi, anapumua kwa haraka au shida, au mtoto mchanga (chini ya siku 28) ana homa.",
            source = "WHO IMCI & Ministry of Health Tanzania",
            publishedDate = "2026-10-18",
            targetAgeLabel = "0–5 Years"
        ),
        HealthEducationItem(
            id = "edu_newborn",
            categoryEn = "Newborn Care & Breastfeeding",
            categorySw = "Malezi ya Mtoto Mchanga & Kunyonyesha",
            titleEn = "Essential Newborn Thermal Care & Exclusive Breastfeeding",
            titleSw = "Joto Salama la Mtoto Mchanga na Maziwa ya Mama Pekee",
            summaryEn = "Keep newborns warm via skin-to-skin contact (Kangaroo Mother Care), keep the umbilical cord clean and dry, and feed exclusively with breast milk on demand for the first 6 months without water or porridge.",
            summarySw = "Mweke mtoto mchanga joto kwa kumkumbatia ngozi kwa ngozi, weka kitovu safi na kikavu, na mnyonyeshe maziwa ya mama pekee kwa miezi 6 ya kwanza bila maji au uji.",
            source = "UNICEF & Tanzania MoH RCH Guidelines",
            publishedDate = "2026-09-25",
            targetAgeLabel = "0–6 Months"
        ),
        HealthEducationItem(
            id = "edu_malaria",
            categoryEn = "Malaria Prevention",
            categorySw = "Kuzuia Malaria",
            titleEn = "Protecting Children from Malaria in Tanzania",
            titleSw = "Kumlinda Mtoto Dhidi ya Malaria Tanzania",
            summaryEn = "Ensure every child sleeps under an insecticide-treated mosquito net every night. Any fever in malaria-endemic regions requires prompt malaria rapid diagnostic testing (mRDT) at a clinic before treatment.",
            summarySw = "Hakikisha mtoto analala ndani ya chandarua kilichotiwa dawa kila usiku. Homa yoyote inahitaji kipimo cha malaria (mRDT) kituo cha afya kabla ya dawa.",
            source = "National Malaria Control Programme (NMCP) Tanzania",
            publishedDate = "2026-11-02",
            targetAgeLabel = "All Ages (0–13y)"
        ),
        HealthEducationItem(
            id = "edu_diarrhea",
            categoryEn = "Diarrhea Prevention & ORS",
            categorySw = "Kuzuia Kuhara & Maji ya ORS",
            titleEn = "Safe Hydration with Low-Osmolarity ORS & Zinc",
            titleSw = "Matibabu Salama kwa ORS na Vidonge vya Zinc",
            summaryEn = "Prevent dehydration during acute watery diarrhea with ORS after every loose stool, continue breastfeeding or feeding, and complete the 10–14 day Zinc course as advised by a clinician. Wash hands with soap before feeding.",
            summarySw = "Zuia upungufu wa maji mwilini kwa kumpa mtoto maji ya ORS kila anapohara, endelea kumnyonyesha au kumlisha, na kamilisha dozi ya Zinc kama ulivyoelekezwa. Nawa mikono kwa sabuni.",
            source = "WHO & UNICEF",
            publishedDate = "2026-10-10",
            targetAgeLabel = "1 Month–13 Years"
        ),
        HealthEducationItem(
            id = "edu_nutrition",
            categoryEn = "Infant & Child Nutrition",
            categorySw = "Lishe Bora kwa Mtoto",
            titleEn = "Complementary Feeding from 6 Months & School-Age Nutrition",
            titleSw = "Vyakula vya Nyongeza Kuanzia Miezi 6",
            summaryEn = "At 6 months, introduce thick, nutrient-dense meals alongside breast milk: mashed beans/fish/eggs, dark leafy greens, orange fruits, and fortified porridge. Limit sugary snacks and monitor weight monthly.",
            summarySw = "Kuanzia miezi 6, anza vyakula vyenye virutubisho vingi pamoja na maziwa ya mama: maharage, samaki, mayai, mboga za majani, matunda, na uji ulioimarishwa.",
            source = "Tanzania Food & Nutrition Centre (TFNC)",
            publishedDate = "2026-08-30",
            targetAgeLabel = "6 Months–13 Years"
        ),
        HealthEducationItem(
            id = "edu_respiratory",
            categoryEn = "Respiratory Infections & Hygiene",
            categorySw = "Magonjwa ya Upumuaji & Usafi",
            titleEn = "Spotting Pneumonia Early & Clean Air Practices",
            titleSw = "Kutambua Nimonia Mapema na Hewa Safi",
            summaryEn = "Count breaths per minute when calm: fast breathing (>=60/min under 2m, >=50/min 2–12m, >=40/min 1–5y) or lower chest wall pulling inward needs urgent clinical care. Keep indoor cooking smoke away from infants.",
            summarySw = "Kupumua haraka au kifua kubonyea ndani ni dalili ya nimonia inayohitaji matibabu ya haraka hospitalini. Epuka moshi wa jikoni karibu na watoto.",
            source = "WHO Child Health Standards",
            publishedDate = "2026-10-04",
            targetAgeLabel = "0–13 Years"
        ),
        HealthEducationItem(
            id = "edu_dental_safety",
            categoryEn = "Dental, Mental & Accident Prevention",
            categorySw = "Meno, Afya ya Akili & Usalama",
            titleEn = "Child Safety, Playful Development & Dental Hygiene",
            titleSw = "Usalama wa Mtoto, Michezo na Usafi wa Meno",
            summaryEn = "Brush teeth twice daily with a smear of fluoride toothpaste once first teeth erupt. Store medicines and paraffin locked high away from toddlers, and encourage daily interactive reading, talk, and safe play.",
            summarySw = "Piga mswaki mara mbili kwa siku meno yanapoanza kuota. Hifadhi dawa na mafuta ya taa mbali na watoto wadogo, na zungumza na kucheza nao kila siku.",
            source = "UNICEF Early Childhood Development",
            publishedDate = "2026-09-12",
            targetAgeLabel = "1–13 Years"
        )
    )
}
