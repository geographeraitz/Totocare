package com.example.data

import android.graphics.Bitmap
import android.util.Log
import com.example.core.AppLanguage
import com.example.core.CryAudioRecording
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class SymptomAssessmentResult(
    val riskLevel: RiskLevel,
    val possibleExplanations: String,
    val nextSteps: String,
    val whenToVisitHospital: String,
    val healthEducation: String,
    val pediatricianSuggestion: String,
    val clinicalDisclaimer: String
)

data class CryAnalysisResult(
    val riskLevel: RiskLevel,
    val primaryPatterns: List<String>,
    val acousticSummary: String,
    val uncertaintyNotice: String,
    val emergencyWarningCheck: String,
    val recommendedNextSteps: String,
    val shouldEscalateToDoctor: Boolean
)

class TotoAiService {

    private val symptomSchema = Schema.obj(
        properties = mapOf(
            "riskLevel" to Schema.enumeration(
                values = listOf("RED", "ORANGE", "YELLOW", "GREEN"),
                description = "Clinical triage risk level. Never return GREEN if any serious or red-flag symptom is reported."
            ),
            "possibleExplanations" to Schema.string(description = "Non-diagnostic possible explanations tailored to child's age group"),
            "nextSteps" to Schema.string(description = "Clear, safe, actionable next steps for the parent"),
            "whenToVisitHospital" to Schema.string(description = "Specific danger signs requiring immediate hospital visit"),
            "healthEducation" to Schema.string(description = "Age-relevant preventive health education"),
            "pediatricianSuggestion" to Schema.string(description = "Recommendation on consulting a qualified pediatrician"),
            "clinicalDisclaimer" to Schema.string(description = "Explicit statement that this is not a confirmed medical diagnosis")
        )
    )

    private val crySchema = Schema.obj(
        properties = mapOf(
            "riskLevel" to Schema.enumeration(
                values = listOf("RED", "ORANGE", "YELLOW", "GREEN"),
                description = "Urgency classification combining audio patterns and parent symptom answers."
            ),
            "primaryPatterns" to Schema.array(
                items = Schema.string(),
                description = "Possible non-diagnostic associations such as hunger, sleepiness, discomfort, need for attention, possible pain, or unusual distress."
            ),
            "acousticSummary" to Schema.string(description = "Observations on intensity, duration, pitch, and vocal rhythm"),
            "uncertaintyNotice" to Schema.string(description = "Explicit explanation of what crying audio can and cannot infer, never claiming to diagnose a disease"),
            "emergencyWarningCheck" to Schema.string(description = "Follow-up warning sign check and escalation advice"),
            "recommendedNextSteps" to Schema.string(description = "Calming steps and when to consult a qualified doctor"),
            "shouldEscalateToDoctor" to Schema.boolean(description = "True if concerning patterns or warning symptoms appear")
        )
    )

    private val symptomModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = symptomSchema
            }
        )
    }

    private val cryModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = crySchema
            }
        )
    }

    private val assistantModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    "You are TOTOCARE AI Child Health Assistant supporting parents and guardians in Tanzania and globally. " +
                        "Respond warmly in the user's chosen language (English or Kiswahili). " +
                        "You help explain child health topics (0 months to 13 years), Tanzania Ministry of Health & WHO vaccination schedules, " +
                        "nutrition, malaria/diarrhea/respiratory prevention, clinic records, and preparing questions for pediatricians. " +
                        "NEVER diagnose diseases, NEVER prescribe medications or medication doses, and ALWAYS advise immediate emergency hospital care for danger signs (convulsions, difficulty breathing, inability to drink/breastfeed, extreme lethargy, newborn fever)."
                )
            }
        )
    }

    suspend fun assessChildSymptoms(
        child: ChildProfile?,
        ageGroup: AgeGroup,
        symptomsText: String,
        selectedSymptoms: List<String>,
        guidedAnswers: Map<String, String>,
        language: AppLanguage,
        attachedImage: Bitmap? = null
    ): Result<SymptomAssessmentResult> {
        return try {
            val langInstruction = if (language == AppLanguage.KISWAHILI) {
                "Respond in clear, empathetic Kiswahili."
            } else {
                "Respond in clear, empathetic English."
            }

            val prompt = buildString {
                appendLine("Perform a pediatric safety triage assessment for TOTOCARE.")
                appendLine(langInstruction)
                appendLine("Child Age Group: ${ageGroup.labelEn} (${ageGroup.rangeLabel})")
                if (child != null) {
                    appendLine("Child Name: ${child.fullName}, Age (months): ${child.ageMonths}, Gender: ${child.gender}")
                    if (child.allergies.isNotBlank()) appendLine("Known Allergies: ${child.allergies}")
                    if (child.existingConditions.isNotBlank()) appendLine("Existing Conditions: ${child.existingConditions}")
                    if (child.medications.isNotBlank()) appendLine("Current Medications: ${child.medications}")
                }
                appendLine("Reported Symptoms Text: ${symptomsText.ifBlank { "None typed" }}")
                appendLine("Selected Library Symptoms: ${selectedSymptoms.joinToString(", ").ifBlank { "None" }}")
                appendLine("Guided Safety Checks: ${guidedAnswers.entries.joinToString("; ") { "${it.key}: ${it.value}" }}")
                appendLine()
                appendLine("CLINICAL SAFETY RULES:")
                appendLine("1. NEVER present this as a confirmed medical diagnosis.")
                appendLine("2. If child is a NEWBORN (0-28 days) with fever, poor feeding, or lethargy, OR if ANY red flag exists (difficulty breathing, convulsions, unconsciousness, persistent vomiting, dehydration, severe bleeding), classify as RED.")
                appendLine("3. NEVER return GREEN if any serious symptom is reported.")
                appendLine("4. Never prescribe specific medication doses.")
            }

            val response = withTimeout(60_000L) {
                symptomModel.generateContent(
                    content {
                        text(prompt)
                        if (attachedImage != null) {
                            image(attachedImage)
                        }
                    }
                )
            }

            val rawJson = response.text ?: throw IllegalStateException("Empty AI response.")
            val json = JSONObject(rawJson)
            Result.success(
                SymptomAssessmentResult(
                    riskLevel = RiskLevel.fromCode(json.optString("riskLevel", "YELLOW")),
                    possibleExplanations = json.optString("possibleExplanations"),
                    nextSteps = json.optString("nextSteps"),
                    whenToVisitHospital = json.optString("whenToVisitHospital"),
                    healthEducation = json.optString("healthEducation"),
                    pediatricianSuggestion = json.optString("pediatricianSuggestion"),
                    clinicalDisclaimer = json.optString("clinicalDisclaimer")
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Symptom assessment timed out", e)
            Result.failure(Exception("Assessment timed out after 60s. If your child has urgent symptoms, go to the nearest hospital immediately."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Symptom assessment failed", e)
            Result.failure(e)
        }
    }

    suspend fun analyzeBabyCry(
        child: ChildProfile?,
        recording: CryAudioRecording,
        extraWarningAnswers: Map<String, String>,
        parentNotes: String,
        language: AppLanguage
    ): Result<CryAnalysisResult> {
        return try {
            val langInstruction = if (language == AppLanguage.KISWAHILI) {
                "Respond in clear, gentle Kiswahili."
            } else {
                "Respond in clear, gentle English."
            }

            val prompt = buildString {
                appendLine("Analyze this infant/child cry audio recording for TOTOCARE.")
                appendLine(langInstruction)
                appendLine("Child Info: ${child?.let { "${it.fullName}, ${it.ageMonths} months (${it.ageGroup})" } ?: "Infant / Young Child"}")
                appendLine(
                    "Measured Acoustic Telemetry: duration=${"%.1f".format(recording.durationSeconds)}s, " +
                        "RMS=${"%.1f".format(recording.rmsEnergyDb)}dBFS, peak=${recording.peakAmplitude}/32767, " +
                        "estimatedPitch=${recording.estimatedPitchHz}Hz"
                )
                appendLine("Parent Notes: ${parentNotes.ifBlank { "None" }}")
                appendLine("Additional Symptom Checks: ${extraWarningAnswers.entries.joinToString("; ") { "${it.key}: ${it.value}" }}")
                appendLine()
                appendLine("STRICT SCIENTIFIC & SAFETY CONSTRAINTS:")
                appendLine("1. Investigate patterns such as hunger, sleepiness, discomfort, need for attention, possible pain, or unusual distress.")
                appendLine("2. Clearly communicate uncertainty — explain what audio analysis CAN and CANNOT infer.")
                appendLine("3. NEVER claim to identify or diagnose a specific disease from crying alone.")
                appendLine("4. If additional symptom answers indicate fever, breathing trouble, inconsolable high-pitched distress, or poor feeding, escalate riskLevel to RED or ORANGE and set shouldEscalateToDoctor=true.")
            }

            val response = withTimeout(60_000L) {
                cryModel.generateContent(
                    content {
                        if (recording.wavBytes.size < 18_000_000) {
                            inlineData(recording.wavBytes, "audio/wav")
                        }
                        text(prompt)
                    }
                )
            }

            val rawJson = response.text ?: throw IllegalStateException("Empty AI response for cry analysis.")
            val json = JSONObject(rawJson)
            val arr = json.optJSONArray("primaryPatterns")
            val patterns = if (arr != null) {
                (0 until arr.length()).map { arr.getString(it) }
            } else {
                emptyList()
            }

            Result.success(
                CryAnalysisResult(
                    riskLevel = RiskLevel.fromCode(json.optString("riskLevel", "YELLOW")),
                    primaryPatterns = patterns,
                    acousticSummary = json.optString("acousticSummary"),
                    uncertaintyNotice = json.optString("uncertaintyNotice"),
                    emergencyWarningCheck = json.optString("emergencyWarningCheck"),
                    recommendedNextSteps = json.optString("recommendedNextSteps"),
                    shouldEscalateToDoctor = json.optBoolean("shouldEscalateToDoctor", false)
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Cry analysis timed out", e)
            Result.failure(Exception("Audio analysis timed out. If your baby seems in acute distress, please seek medical evaluation."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Cry analysis failed", e)
            Result.failure(e)
        }
    }

    fun streamHealthAssistant(
        question: String,
        child: ChildProfile?,
        language: AppLanguage
    ): Flow<String> = flow {
        val langNote = if (language == AppLanguage.KISWAHILI) "Kiswahili" else "English"
        val contextHeader = child?.let {
            "Active child context: ${it.fullName}, age ${it.ageMonths} months (${it.ageGroup}), allergies: ${it.allergies.ifBlank { "none reported" }}."
        } ?: "No specific child selected."

        val prompt = "$contextHeader\nPreferred language: $langNote.\nParent question: $question"
        val sb = StringBuilder()
        withTimeout(60_000L) {
            assistantModel.generateContentStream(prompt).collect { chunk ->
                val part = chunk.text.orEmpty()
                if (part.isNotEmpty()) {
                    sb.append(part)
                    emit(sb.toString())
                }
            }
        }
        if (sb.isBlank()) {
            throw IllegalStateException("AI Assistant returned an empty response.")
        }
    }

    private companion object {
        const val TAG = "TotoAiService"
    }
}
