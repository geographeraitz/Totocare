package com.example.data

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class AgeGroup(
    val code: String,
    val labelEn: String,
    val labelSw: String,
    val rangeLabel: String
) {
    NEWBORN("NEWBORN", "Newborn", "Mtoto Mchanga", "0–28 days"),
    INFANT("INFANT", "Infant", "Mtoto Mdogo", "1–12 months"),
    TODDLER("TODDLER", "Toddler", "Mtoto Anayekua", "1–3 years"),
    PRESCHOOL("PRESCHOOL", "Preschool", "Kabla ya Shule", "4–5 years"),
    SCHOOL_AGE("SCHOOL_AGE", "School-Age", "Umri wa Shule", "6–13 years");

    companion object {
        fun fromCode(raw: String?): AgeGroup =
            entries.firstOrNull { it.code == raw } ?: INFANT

        fun fromMonths(months: Long): AgeGroup = when {
            months <= 1L -> NEWBORN
            months <= 12L -> INFANT
            months <= 36L -> TODDLER
            months <= 60L -> PRESCHOOL
            else -> SCHOOL_AGE
        }
    }
}

enum class RiskLevel(
    val code: String,
    val labelEn: String,
    val labelSw: String,
    val guidanceEn: String,
    val guidanceSw: String
) {
    RED(
        "RED",
        "RED — Emergency",
        "NYEKUNDU — Dharura",
        "Potential life-threatening emergency. Seek emergency hospital attention immediately.",
        "Dalili za hatari kubwa. Mpeleke mtoto hospitalini au kituo cha dharura mara moja."
    ),
    ORANGE(
        "ORANGE",
        "ORANGE — Urgent",
        "MACHUNGWA — Haraka",
        "Serious warning signs requiring urgent medical assessment today.",
        "Dalili zinazohitaji uchunguzi wa haraka wa daktari leo."
    ),
    YELLOW(
        "YELLOW",
        "YELLOW — Soon",
        "NJANO — Mapema",
        "Medical assessment recommended soon. Monitor closely and book a consultation.",
        "Uchunguzi wa kitabibu unapendekezwa mapema. Endelea kufuatilia kwa karibu."
    ),
    GREEN(
        "GREEN",
        "GREEN — Routine",
        "KIJANI — Kawaida",
        "General health guidance and routine monitoring, provided no danger signs appear.",
        "Mwongozo wa kawaida wa afya na ufuatiliaji nyumbani iwapo hakuna dalili hatari."
    );

    companion object {
        fun fromCode(raw: String?): RiskLevel =
            entries.firstOrNull { it.code == raw?.uppercase() } ?: YELLOW
    }
}

enum class WorkspaceRole(val code: String, val labelEn: String, val labelSw: String) {
    PARENT("parent", "Parent / Guardian", "Mzazi / Mlezi"),
    DOCTOR("doctor", "Doctor / Specialist", "Daktari / Bingwa"),
    PHARMACY("pharmacy", "Pharmacy Partner", "Duka la Dawa"),
    ADMIN("admin", "Platform Admin", "Msimamizi Mkuu");

    companion object {
        fun fromCode(raw: String?): WorkspaceRole =
            entries.firstOrNull { it.code == raw } ?: PARENT
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val caregiverRole: String = "parent",
    val language: String = "en",
    val countryCode: String = "TZ",
    val workspaceRole: String = "parent",
    val emergencyContactName: String = "",
    val emergencyContactPhone: String = "",
    val twoFactorEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ChildProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val dobText: String = "",
    val ageMonths: Long = 12L,
    val ageGroup: String = "INFANT",
    val gender: String = "Female",
    val birthWeightKg: Double = 3.2,
    val bloodGroup: String = "",
    val location: String = "Dar es Salaam, Tanzania",
    val allergies: String = "",
    val previousIllnesses: String = "",
    val existingConditions: String = "",
    val medications: String = "",
    val emergencyContactName: String = "",
    val emergencyContactPhone: String = "",
    val photoUri: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class VaccinationRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val childId: String = "",
    val childName: String = "",
    val vaccineName: String = "",
    val ageScheduleLabel: String = "",
    val doseLabel: String = "",
    val status: String = "upcoming",
    val scheduledDateText: String = "",
    val administeredDateText: String = "",
    val clinicName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class GrowthMeasurement(
    @DocumentId val id: String = "",
    val userId: String = "",
    val childId: String = "",
    val childName: String = "",
    val weightKg: Double = 0.0,
    val heightCm: Double = 0.0,
    val headCircumferenceCm: Double = 0.0,
    val recordedDateText: String = "",
    val milestoneNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class HealthAssessment(
    @DocumentId val id: String = "",
    val userId: String = "",
    val childId: String = "",
    val childName: String = "",
    val kind: String = "symptom",
    val ageGroup: String = "INFANT",
    val symptomsSummary: String = "",
    val riskLevel: String = "YELLOW",
    val aiExplanation: String = "",
    val nextSteps: String = "",
    val emergencyTriggered: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CareNotification(
    @DocumentId val id: String = "",
    val userId: String = "",
    val childId: String = "",
    val title: String = "",
    val body: String = "",
    val category: String = "clinic",
    val readStatus: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ConsultationRecord(
    @DocumentId val id: String = "",
    val parentUid: String = "",
    val parentName: String = "",
    val childId: String = "",
    val childName: String = "",
    val doctorId: String = "",
    val doctorName: String = "",
    val specialty: String = "",
    val consultationMode: String = "video",
    val scheduledSlot: String = "",
    val symptomsSummary: String = "",
    val attachmentSummary: String = "",
    val status: String = "requested",
    val doctorNotes: String = "",
    val prescriptionText: String = "",
    val referralSpecialty: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ConsultationMessage(
    @DocumentId val id: String = "",
    val parentUid: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val senderRole: String = "parent",
    val body: String = "",
    val attachmentLabel: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PharmacyOrder(
    @DocumentId val id: String = "",
    val parentUid: String = "",
    val parentName: String = "",
    val childName: String = "",
    val pharmacyName: String = "",
    val medicineName: String = "",
    val quantity: Long = 1L,
    val totalTzs: Long = 0L,
    val requiresPrescription: Boolean = false,
    val prescriptionNote: String = "",
    val deliveryMode: String = "delivery",
    val deliveryAddress: String = "",
    val status: String = "pending_verification",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ProviderApplication(
    @DocumentId val id: String = "",
    val userId: String = "",
    val providerType: String = "doctor",
    val applicantName: String = "",
    val facilityName: String = "",
    val licenseNumber: String = "",
    val specialty: String = "",
    val region: String = "Dar es Salaam",
    val verificationStatus: String = "pending",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class OfficialHealthBulletin(
    @DocumentId val id: String = "",
    val title: String = "",
    val source: String = "",
    val publishedDate: String = "",
    val category: String = "",
    val summary: String = "",
    val language: String = "en",
    val published: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
