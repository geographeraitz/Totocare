package com.example.core

enum class AppLanguage(val code: String, val displayLabel: String) {
    ENGLISH("en", "English"),
    KISWAHILI("sw", "Kiswahili");

    companion object {
        fun fromCode(code: String): AppLanguage =
            entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}

data class CountryConfig(
    val code: String,
    val name: String,
    val flagEmoji: String,
    val emergencyNumber: String,
    val ambulanceNumber: String,
    val currencyCode: String,
    val ministryName: String,
    val immunizationNote: String
)

object GlobalCountryCatalog {
    val countries = listOf(
        CountryConfig(
            code = "TZ",
            name = "Tanzania",
            flagEmoji = "\uD83C\uDDF9\uD83C\uDDFF",
            emergencyNumber = "112",
            ambulanceNumber = "114",
            currencyCode = "TZS",
            ministryName = "Ministry of Health Tanzania (Wizara ya Afya)",
            immunizationNote = "Tanzania National EPI Schedule (BCG, OPV, Penta, PCV, Rota, MR, Vitamin A)"
        ),
        CountryConfig(
            code = "KE",
            name = "Kenya",
            flagEmoji = "\uD83C\uDDF0\uD83C\uDDEA",
            emergencyNumber = "999",
            ambulanceNumber = "112",
            currencyCode = "KES",
            ministryName = "Ministry of Health Kenya",
            immunizationNote = "KEPI Schedule (BCG, OPV, Penta, PCV-10, Rota, Measles-Rubella)"
        ),
        CountryConfig(
            code = "UG",
            name = "Uganda",
            flagEmoji = "\uD83C\uDDFA\uD83C\uDDEC",
            emergencyNumber = "112",
            ambulanceNumber = "999",
            currencyCode = "UGX",
            ministryName = "Ministry of Health Uganda",
            immunizationNote = "UNEPI Schedule (BCG, OPV, DPT-HepB-Hib, PCV, MR)"
        ),
        CountryConfig(
            code = "RW",
            name = "Rwanda",
            flagEmoji = "\uD83C\uDDF7\uD83C\uDDFC",
            emergencyNumber = "112",
            ambulanceNumber = "912",
            currencyCode = "RWF",
            ministryName = "Rwanda Biomedical Centre / MoH",
            immunizationNote = "Rwanda National Immunization Program"
        ),
        CountryConfig(
            code = "BI",
            name = "Burundi",
            flagEmoji = "\uD83C\uDDE7\uD83C\uDDEE",
            emergencyNumber = "112",
            ambulanceNumber = "118",
            currencyCode = "BIF",
            ministryName = "Ministère de la Santé Publique",
            immunizationNote = "PEV Burundi Immunization Schedule"
        ),
        CountryConfig(
            code = "ZA",
            name = "South Africa",
            flagEmoji = "\uD83C\uDDFF\uD83C\uDDE6",
            emergencyNumber = "10177",
            ambulanceNumber = "112",
            currencyCode = "ZAR",
            ministryName = "Department of Health South Africa",
            immunizationNote = "EPI-SA Road to Health Immunization Schedule"
        ),
        CountryConfig(
            code = "NG",
            name = "Nigeria",
            flagEmoji = "\uD83C\uDDF3\uD83C\uDDEC",
            emergencyNumber = "112",
            ambulanceNumber = "112",
            currencyCode = "NGN",
            ministryName = "NPHCDA / Federal Ministry of Health",
            immunizationNote = "Nigeria National Immunization Schedule"
        ),
        CountryConfig(
            code = "GH",
            name = "Ghana",
            flagEmoji = "\uD83C\uDDEC\uD83C\uDDED",
            emergencyNumber = "112",
            ambulanceNumber = "193",
            currencyCode = "GHS",
            ministryName = "Ghana Health Service",
            immunizationNote = "Ghana EPI Schedule"
        ),
        CountryConfig(
            code = "GLOBAL",
            name = "Global / WHO",
            flagEmoji = "\uD83C\uDF0D",
            emergencyNumber = "112",
            ambulanceNumber = "911",
            currencyCode = "USD",
            ministryName = "World Health Organization (WHO)",
            immunizationNote = "WHO Global Routine Immunization Recommendations"
        )
    )

    fun byCode(code: String): CountryConfig =
        countries.firstOrNull { it.code == code } ?: countries.first()
}

data class TotoStrings(
    val brandTagline: String,
    val signInTitle: String,
    val signInSubtitle: String,
    val signInButton: String,
    val navHome: String,
    val navAssess: String,
    val navClinic: String,
    val navCare: String,
    val navPortals: String,
    val sosEmergency: String,
    val emergencyHelpTitle: String,
    val checkSymptoms: String,
    val recordBabyCry: String,
    val aiAssistant: String,
    val nearbyHospitals: String,
    val talkToDoctor: String,
    val clinicAndVaccines: String,
    val growthMonitor: String,
    val pharmacyMarket: String,
    val healthEducation: String,
    val medicalRecords: String,
    val notifications: String,
    val addChild: String,
    val noChildYet: String,
    val medicalDisclaimer: String
)

fun stringsFor(language: AppLanguage): TotoStrings = when (language) {
    AppLanguage.ENGLISH -> TotoStrings(
        brandTagline = "Every Child Deserves a Healthy Future.",
        signInTitle = "Trusted AI Pediatric Care for Every Family",
        signInSubtitle = "Monitor your child's health from birth to 13 years with early warning triage, vaccination tracking, baby cry insights, and licensed Tanzanian & global pediatricians.",
        signInButton = "Sign in with Google",
        navHome = "Home",
        navAssess = "AI Care",
        navClinic = "Clinic",
        navCare = "Services",
        navPortals = "Portals",
        sosEmergency = "SOS",
        emergencyHelpTitle = "Child Emergency Assistance",
        checkSymptoms = "Check Symptoms",
        recordBabyCry = "Baby Cry AI",
        aiAssistant = "AI Assistant",
        nearbyHospitals = "Nearby Hospitals",
        talkToDoctor = "Talk to Doctor",
        clinicAndVaccines = "Clinic & Vaccines",
        growthMonitor = "Growth Chart",
        pharmacyMarket = "Pharmacy",
        healthEducation = "Education",
        medicalRecords = "Medical Records",
        notifications = "Reminders",
        addChild = "Register Child",
        noChildYet = "Register your first child profile to unlock personalized age-based AI care, Tanzania EPI vaccination reminders, and growth tracking.",
        medicalDisclaimer = "Educational & triage guidance only — never a confirmed medical diagnosis. Seek urgent hospital care if danger signs appear."
    )

    AppLanguage.KISWAHILI -> TotoStrings(
        brandTagline = "Kila Mtoto Anastahili Maisha Yenye Afya.",
        signInTitle = "Huduma Bora za Afya ya Mtoto kwa Msaada wa AI",
        signInSubtitle = "Fuatilia afya ya mtoto wako kuanzia kuzaliwa hadi miaka 13: uchunguzi wa dalili, uchambuzi wa kilio cha mtoto, chanjo za Wizara ya Afya, na madaktari bingwa wa watoto.",
        signInButton = "Ingia kwa Google",
        navHome = "Nyumbani",
        navAssess = "Huduma AI",
        navClinic = "Kliniki",
        navCare = "Huduma",
        navPortals = "Mfumo",
        sosEmergency = "DHARURA",
        emergencyHelpTitle = "Msaada wa Dharura kwa Mtoto",
        checkSymptoms = "Angalia Dalili",
        recordBabyCry = "Kilio cha Mtoto",
        aiAssistant = "Msaidizi AI",
        nearbyHospitals = "Hospitali Karibu",
        talkToDoctor = "Ongea na Daktari",
        clinicAndVaccines = "Kliniki & Chanjo",
        growthMonitor = "Ukuaji",
        pharmacyMarket = "Duka la Dawa",
        healthEducation = "Elimu ya Afya",
        medicalRecords = "Kumbukumbu",
        notifications = "Vikumbusho",
        addChild = "Sajili Mtoto",
        noChildYet = "Sajili wasifu wa mtoto wako wa kwanza ili kupata mwongozo wa AI kulingana na umri, ratiba ya chanjo ya Tanzania, na ufuatiliaji wa ukuaji.",
        medicalDisclaimer = "Mwongozo wa elimu na tathmini ya awali tu — si utambuzi rasmi wa kitabibu. Mpeleke mtoto hospitalini mara moja dalili hatari zikionekana."
    )
}
