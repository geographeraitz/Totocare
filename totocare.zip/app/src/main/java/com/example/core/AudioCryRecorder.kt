package com.example.core

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

data class CryAudioRecording(
    val wavBytes: ByteArray,
    val durationSeconds: Double,
    val rmsEnergyDb: Double,
    val peakAmplitude: Int,
    val estimatedPitchHz: Int,
    val waveformBars: List<Float>
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is CryAudioRecording) return false
        return wavBytes.contentEquals(other.wavBytes) && durationSeconds == other.durationSeconds
    }

    override fun hashCode(): Int {
        var result = wavBytes.contentHashCode()
        result = 31 * result + durationSeconds.hashCode()
        return result
    }
}

object AudioCryRecorder {
    private const val SAMPLE_RATE = 16000
    private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
    private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT

    @SuppressLint("MissingPermission")
    suspend fun recordSample(
        durationMillis: Long = 4500L,
        onAmplitude: (Float) -> Unit
    ): Result<CryAudioRecording> = withContext(Dispatchers.IO) {
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (minBuf == AudioRecord.ERROR || minBuf == AudioRecord.ERROR_BAD_VALUE) {
            return@withContext Result.failure(IllegalStateException("Audio microphone hardware unavailable."))
        }
        val bufferSize = maxOf(minBuf * 2, 4096)
        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            bufferSize
        )

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            return@withContext Result.failure(IllegalStateException("Microphone could not initialize."))
        }

        val pcmStream = ByteArrayOutputStream()
        val shortBuf = ShortArray(bufferSize / 2)
        val bars = mutableListOf<Float>()
        var sumSquares = 0.0
        var totalSamples = 0L
        var maxAmp = 0
        var zeroCrossings = 0
        var prevSample: Short = 0

        try {
            recorder.startRecording()
            val startTime = System.currentTimeMillis()
            while (System.currentTimeMillis() - startTime < durationMillis) {
                val read = recorder.read(shortBuf, 0, shortBuf.size)
                if (read > 0) {
                    var chunkPeak = 0
                    val byteBuffer = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until read) {
                        val s = shortBuf[i]
                        byteBuffer.putShort(s)
                        val absS = abs(s.toInt())
                        if (absS > maxAmp) maxAmp = absS
                        if (absS > chunkPeak) chunkPeak = absS
                        sumSquares += s.toDouble() * s.toDouble()
                        if ((prevSample < 0 && s >= 0) || (prevSample >= 0 && s < 0)) {
                            zeroCrossings++
                        }
                        prevSample = s
                    }
                    pcmStream.write(byteBuffer.array())
                    totalSamples += read
                    val normalized = (chunkPeak / 32767f).coerceIn(0.05f, 1f)
                    bars.add(normalized)
                    withContext(Dispatchers.Main) {
                        onAmplitude(normalized)
                    }
                }
            }
            recorder.stop()
        } catch (e: Exception) {
            return@withContext Result.failure(e)
        } finally {
            try {
                recorder.release()
            } catch (_: Exception) {
            }
        }

        val pcmBytes = pcmStream.toByteArray()
        val durationSec = if (totalSamples > 0) totalSamples.toDouble() / SAMPLE_RATE else durationMillis / 1000.0
        val rms = if (totalSamples > 0) sqrt(sumSquares / totalSamples) else 1.0
        val rmsDb = 20.0 * kotlin.math.log10((rms / 32767.0).coerceAtLeast(1e-6))
        val estimatedHz = if (durationSec > 0) ((zeroCrossings / 2.0) / durationSec).toInt().coerceIn(80, 1200) else 0
        val wavBytes = encodeWav(pcmBytes, SAMPLE_RATE, 1, 16)

        val sampledBars = if (bars.size <= 24) {
            bars
        } else {
            val step = bars.size / 24
            (0 until 24).map { idx -> bars[(idx * step).coerceAtMost(bars.lastIndex)] }
        }

        Result.success(
            CryAudioRecording(
                wavBytes = wavBytes,
                durationSeconds = durationSec,
                rmsEnergyDb = rmsDb,
                peakAmplitude = maxAmp,
                estimatedPitchHz = estimatedHz,
                waveformBars = sampledBars
            )
        )
    }

    private fun encodeWav(
        pcmData: ByteArray,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val dataSize = pcmData.size
        val chunkSize = 36 + dataSize

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(chunkSize)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1.toShort())
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(blockAlign.toShort())
        header.putShort(bitsPerSample.toShort())
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(dataSize)

        return header.array() + pcmData
    }
}
